define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveSlotButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      const isBlank = (col) => col == null || col === "" || col === "undefined";

      if (isBlank($variables.creationSlotVariables.configNumber) || isBlank($variables.creationSlotVariables.demandClass) || isBlank($variables.creationSlotVariables.mrpQtr)
        || isBlank($variables.creationSlotVariables.pdQtr) || isBlank($variables.creationSlotVariables.promisedDate) || isBlank($variables.creationSlotVariables.scheduledDate)
        || isBlank($variables.creationSlotVariables.slotStatus) || isBlank($variables.creationSlotVariables.slotType)
        || isBlank($variables.creationSlotVariables.system || isBlank($variables.creationSlotVariables.platform) || isBlank($variables.creationSlotVariables.platform))) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Please provide all the Required Fields!',
          type: 'error',
          displayMode: 'transient',
        });

      } else {

        if ($variables.creationSlotVariables.slotNumber !== null && $variables.creationSlotVariables.slotNumber !== undefined && $variables.creationSlotVariables.slotNumber !== '' && $variables.creationSlotVariables.slotNumber !== 'undefined') {

          const getSlotNumberResponse = await Actions.callRest(context, {
            endpoint: 'ordsService/getPlanDetailsTableAction',
            uriParams: {
              'p_searchvalue': $variables.creationSlotVariables.slotNumber,
            },
          });
          await Actions.fireNotificationEvent(context, {
            summary: 'Slot Number provided already exists!',
            type: 'error',
            displayMode: 'transient',
          });
        }
        else {

          const processPayloads = await $functions.processPayloads($variables.creationSlotVariables, $application.user.fullName);

          const createSlotResponse = await Actions.callRest(context, {
            endpoint: 'ordsService/postPlanDetailsTableAction',
            body: processPayloads,
          });

          if (createSlotResponse.ok === true) {
            await Actions.fireNotificationEvent(context, {
              type: 'confirmation',
              summary: 'Slot created successfully!',
            });

            await Actions.resetVariables(context, {
              variables: [
    '$variables.creationSlotVariables',
  ],
            });
          }
        }
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });
    }
  }

  return saveSlotButtonActionChain;
});
