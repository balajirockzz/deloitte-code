define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onClickQuarterActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {any} params.data
     * @param {any} params.metadata
     * @param {any} params.valueItem
     */
    async run(context, { event, previousValue, value, updatedFrom, key, data, metadata, valueItem }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetdashboardtotal',
        uriParams: {
          'p_mrp_qtr': $variables.quarterVar,
        },
      });

      if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error During Rest Action',
          displayMode: 'persist',
          type: 'error',
        });
      } else {
        $variables.Dashboard_Count_obj.BookedSlots = response.body.items[0].booked_count;
        $variables.Dashboard_Count_obj.IdentifiedSlots = response.body.items[0].identified_count;
        $variables.Dashboard_Count_obj.OpenSlots = response.body.items[0].open_count;
        $variables.Dashboard_Count_obj.ShippedSlots = response.body.items[0].shipped_count;
        $variables.Dashboard_Count_obj.TotalSlots = response.body.items[0].total_count;
      }
    }
  }

  return onClickQuarterActionChain;
});
