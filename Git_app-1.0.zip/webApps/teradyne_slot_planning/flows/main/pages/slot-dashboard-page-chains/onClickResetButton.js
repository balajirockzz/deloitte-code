define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onClickResetButton extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.Search_obj',
    '$variables.Search_obj.search_value',
    '$variables.Search_table_ADP',
    '$variables.Search_table_ADP.data',
    '$variables.exportADP',
    '$variables.exportADP.data',
  ],
      });

      await Actions.callChain(context, {
        chain: 'vbEnterListener',
      });
    }
  }

  return onClickResetButton;
});
