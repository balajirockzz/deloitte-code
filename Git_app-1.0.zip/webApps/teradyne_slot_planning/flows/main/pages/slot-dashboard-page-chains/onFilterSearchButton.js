define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onFilterSearchButton extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetfiltersearch',
        uriParams: {
          'p_customer_name': $variables.Filter_Obj.customer_name,
          'p_period': $variables.Filter_Obj.period,
          'p_product_type': $variables.Filter_Obj.product_type,
          'p_slot_number': $variables.Filter_Obj.slot_number,
          'p_slot_type': $variables.Filter_Obj.slot_type,
          'p_status': $variables.Filter_Obj.status,
        },
      });

      if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Filter Rest Action Error',
          displayMode: 'persist',
          type: 'error',
        });
      } else {

        $variables.Search_table_ADP.data = response.body.items;

        const progressMsgOpen = await Actions.callComponentMethod(context, {
          selector: '#progressMsg',
          method: 'open',
        });

        await Actions.resetVariables(context, {
          variables: [
    '$variables.exportADP',
    '$variables.exportADP.data',
  ],
        });

        const response2 = await Actions.callRest(context, {
          endpoint: 'ordsService/getGetexportdetails',
          uriParams: {
            'p_customer_name': $variables.Filter_Obj.customer_name,
            'p_period': $variables.Filter_Obj.period,
            'p_product_type': $variables.Filter_Obj.product_type,
            'p_slot_number': $variables.Filter_Obj.slot_number,
            'p_slot_type': $variables.Filter_Obj.slot_type,
            'p_status': $variables.Filter_Obj.status,
          },
        });

        if (!response2.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Error in Export Action',
            displayMode: 'persist',
            type: 'error',
          });
        } else {
          $variables.exportADP.data = response2.body.items;

          const progressMsgClose = await Actions.callComponentMethod(context, {
            selector: '#progressMsg',
            method: 'close',
          });
        }

        const searchfilterClose = await Actions.callComponentMethod(context, {
          selector: '#searchfilter',
          method: 'close',
        });
      }
    }
  }

  return onFilterSearchButton;
});
