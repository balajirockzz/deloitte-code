define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;


      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetsearchtable',
      });

      if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error in the Search Api',
        });
      } else {

        $variables.Search_table_ADP.data = response.body.items;
      }

      const response2 = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetdashboardtotal',
      });

      $variables.Dashboard_Count_obj.BookedSlots = response2.body.items[0].booked_count;
      $variables.Dashboard_Count_obj.IdentifiedSlots = response2.body.items[0].identified_count;
      $variables.Dashboard_Count_obj.OpenSlots = response2.body.items[0].open_count;
      $variables.Dashboard_Count_obj.ShippedSlots = response2.body.items[0].shipped_count;
      $variables.Dashboard_Count_obj.TotalSlots = response2.body.items[0].total_count;

      const response3 = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetexportdetails',
      });

      $variables.exportADP.data = response3.body.items;

      const exportfilename = await $functions.getexportfilename();

      $variables.exportFilenameVar = exportfilename;
    }
  }

  return vbEnterListener;
});