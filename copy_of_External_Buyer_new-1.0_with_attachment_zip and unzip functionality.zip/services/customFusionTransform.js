//
// Example code, not for use in production environments.
//
define(['services/fusionTransform',], (fusionTransform) => {
'use strict';

  // Overridden Request transform
  class Request extends fusionTransform.request {
    paginate(configuration, options) {
			// TODO: Add code here
		}
		sort(configuration, options) {
			// TODO: Add code here
		}
		select(configuration, options) {
			// TODO: Add code here
		}
		fetchByKeys(configuration) {
			// TODO: Add code here
		}

  }

  // Overridden Response transform
  class Response extends fusionTransform.response {
    paginate(configuration, context) {
			// TODO: Add code here
		}

  }

  return {
    request: Request,
    response: Response
  };
});