define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class openApprovalsChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.data 
     */
    async run(context, { data }) {
      const { $page, $flow, $application } = context;

      await $application.functions.openSpinnerDialog();

      $flow.variables.actionApprovalADP.data = data.approvals;

      await $application.functions.closeSpinnerDialog();

      const ojDialogApprovalsOpen = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-approvals',
        method: 'open',
      });
    }
  }

  return openApprovalsChain;
});
