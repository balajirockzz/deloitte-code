define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class pageLoadChain extends ActionChain {

    /**
     * @param {Object} context
     * @return {{cancelled:boolean}} 
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $application.functions.openSpinnerDialog();

      let buyerGroups =[];
      let buyerOrgs =[];
      $flow.variables.transReqDetails = {};
      $flow.variables.transReqDetails.buyer_name = $application.user.username;

      if($variables.headerId){

       let response = await Actions.callRest(context, {
         endpoint: 'ords/getPODetails',
         uriParams: {
           id: $page.variables.headerId,
         },
       });

        if (response.ok) {
          // assignPOdetails
          $flow.variables.transReqDetails = response.body;
          $page.variables.requestLinesADP.data = response.body.lines ? response.body.lines : [];

          

        const results = await Promise.all([
          async () => {

      const response3 = await Actions.callRest(context, {
            endpoint: 'fscm/getSuppliersSite',
            uriParams: {
              q: 'SupplierSite in '+ $application.functions.getInClause($flow.variables.supplierAssoc.supplierSiteList),
              SupplierId: $flow.variables.transReqDetails.supplier_id,
            },
      });

          
                  if (response3.ok) {
                
               $page.variables.supplierSIteADP.data = response3.body.items;
                  }
            
           
          },
          async () => {

            const response2 = await Actions.callRest(context, {
              endpoint: 'fscm/getSupplierContacts',
              uriParams: {
                id: $flow.variables.transReqDetails.supplier_id,
              },
            });

            if (response2.ok) {
              $page.variables.supplierContactsADP.data = response2.body.items;
            
            }
          },
            async () => {
              const response4 = await Actions.callRest(context, {
                endpoint: 'fscm/getSupplierAssignments',
                uriParams: {
                  siteId: $flow.variables.transReqDetails.supplier_site_id,
                  supplierId: $flow.variables.transReqDetails.supplier_id,
                },
              });

              if (response4.ok) {
                $page.variables.RequisitionBuADP.data = response4.body.items;
              }
            },
        ].map(sequence => sequence()));
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'API error',
          });
        }
        
      }

  

      await $application.functions.closeSpinnerDialog();

      // Navigation to this page can be canceled by returning an object with the property cancelled set to true. This is useful if the user does not have permission to view this page.
      return { cancelled: false };
    }
  }

  return pageLoadChain;
});
