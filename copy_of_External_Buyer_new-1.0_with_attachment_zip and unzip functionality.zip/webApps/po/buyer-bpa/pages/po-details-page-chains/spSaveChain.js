/* Copyright (c) 2024, Oracle and/or its affiliates */

define(['knockout',
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ko,
  ActionChain,
  Actions
) => {
  'use strict';

  class spSaveChain extends ActionChain {

    /**
     * Submit form data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.submit 
     */
    async run(context, { submit = 'N' }) {
      const { $page, $flow, $variables, $application } = context;

      await $application.functions.openSpinnerDialog();

      // await $application.functions.isFormValid('hdr_form');
       let lines = $page.variables.requestLinesADP.data;
       let isFailed = false;
      if ($application.functions.isFormValid('hdr_form') && lines.length >0) {
         $flow.variables.transReqDetails.lines = lines;
         $flow.variables.transReqDetails.created_by = $application.user.username;
         $flow.variables.transReqDetails.updated_by = $application.user.username;
         $flow.variables.transReqDetails.po_status = (submit ==='N'?'DRAFT':'SUBMIT');
        

       $flow.variables.transReqDetails.SUBMIT =  submit === 'Y' ? 'SUBMIT' : ($flow.variables.transReqDetails.po_status ?  $flow.variables.transReqDetails.po_status:'DRAFT'); 
        const response = await Actions.callRest(context, {
          endpoint: 'ords/postPOdetails',
          body: ko.toJSON( $flow.variables.transReqDetails)
        });

        if (!response.ok) {
           isFailed =true;
          await Actions.fireNotificationEvent(context, {
            summary: 'Rest API Error',
          });
        } else {

          if(response.body.X_RETURN_CODE === 'ERROR'){
             isFailed =true;
                await Actions.fireNotificationEvent(context, {
                  summary: 'PO Save failed',
                  displayMode: 'transient',
                  type: 'confirmation',
                  message: response.body.X_RETURN_MESSAGE,
                });

          }
          
          else
          if(submit === 'Y'){

            let response2 = null;

            if(!$flow.variables.transReqDetails.po_header_id ){

           response2 = await Actions.callRest(context, {
            endpoint: 'ics/postPOCreate',

            body: {"RequestId": response.body.X_RETURN_MESSAGE },
          });
            }
             else {         
               response2 = await Actions.callRest(context, {
                endpoint: 'ics/postPOCreate',
                body: {"RequestId":$flow.variables.transReqDetails.request_id},
              });
            }
            if(response2.ok) {

              if (response2.body.Status === 'ERROR') {
                isFailed =true;
                await Actions.fireNotificationEvent(context, {
                  summary: 'PO Submitted failed',
                  displayMode: 'transient',
                  type: 'error',
                  message: response2.body.Status_Message,
                });
              }
              else{
                await Actions.fireNotificationEvent(context, {
            summary: response2.body.Status_Message ? ( 'PO Submitted: '+response2.body.Status_Message):'PO Submitted',
            displayMode: 'transient',
            type: 'confirmation',
                 });

              }
              
             
          }
          else{
             isFailed =true;
             await Actions.fireNotificationEvent(context, {
            summary: 'PO submittion failed',
            displayMode: 'transient',
            type: 'error',
          });
          }
          }
          else{

            await Actions.fireNotificationEvent(context, {
            summary: 'PO Saved',
            displayMode: 'transient',
            type: 'confirmation',
          });

          }
         
        }
        
        if(!isFailed)
        await Actions.callChain(context, {
          chain: 'spCancelChain',
        });
      
      }
       else {
        await Actions.fireNotificationEvent(context, {
          displayMode: 'transient',
          summary: 'Missing required fields'+(lines.length < 1? ': Atleast One Item Details is mandatory':''),
        });
        
      }

      await $application.functions.closeSpinnerDialog();

    }
  }

  return spSaveChain;
});
