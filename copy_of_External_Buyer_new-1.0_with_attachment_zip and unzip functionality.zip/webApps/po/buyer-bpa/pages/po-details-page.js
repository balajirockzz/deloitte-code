define([], () => {
  'use strict';

  class PageModule {

    generateBIPReportREqPayload(po_number){
let payload =`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest>
            <pub:attributeFormat>csv</pub:attributeFormat>
            <pub:parameterNameValues>
               <pub:item>
                  <pub:name>p_po_number</pub:name>
                  <pub:values>
                     <pub:item>`+po_number+`</pub:item>
                  </pub:values>
               </pub:item>
            </pub:parameterNameValues>
            <pub:reportAbsolutePath>/Custom/Extension/STP/STP_PROC_EXT_005_External_Buyer_PO_ActionHistory_Report.xdo</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
         </pub:reportRequest>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

return payload;

}









      }

     PageModule.prototype.isCrossDivision = function (linesData) {
      let returnVal = 'Y';
      linesData.forEach(element => {
        if(element.from_division !== element.to_division){
          returnVal = 'N';
        }
      });
         return returnVal;
    };

     PageModule.prototype.isSameReviewer = function (linesData) {
      let returnVal = 'Y';
      let from_reviewer = null;
      let to_reviewer = null;
      linesData.forEach(element => {
        if(element.from_reviewer !== element.to_reviewer){
           returnVal = 'N';
        }
        if(from_reviewer && element.from_reviewer !== from_reviewer){
           returnVal = 'FROM';
        }
        if(to_reviewer && element.from_reviewer !== to_reviewer){
           returnVal = 'TO';
        }
        from_reviewer = element.from_reviewer ;
        to_reviewer = element.to_reviewer ;
      });
      return returnVal;
    };

  
  return PageModule;
});
