define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class itemValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application } = context;

     $page.variables.lineDetails.amount =
       $page.variables.lineDetails.ordered_quantity && $page.variables.lineDetails.price ?  ($page.variables.lineDetails.ordered_quantity * $page.variables.lineDetails.price) : null;
    }
  }

  return itemValueChangeChain;
});
