define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navtoPageActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.page 
     */
    async run(context, { page }) {
      const { $application } = context;

      await $application.functions.openSpinnerDialog();

      const toShell2 = await Actions.navigateToPage(context, {
        page: '/shell/'+page,
      });
    }
  }

  return navtoPageActionChain;
});
