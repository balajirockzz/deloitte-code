define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class controlsDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     * @param {string} params.deleteFlag 
     */
    async run(context, { details, deleteFlag = 'N' }) {
      const { $page, $flow, $application, $constants, $variables } = context;

   
     

      if (details && deleteFlag === 'Y') {

        await Actions.fireDataProviderEvent(context, {
          target: $variables.businessControlsADP,
          remove: {
             data: details,
             keys: $variables.controlDetails.OrganizationAssignmentId,
          },
        });
      } else {
         
        if ($application.functions.isFormValid('control_form')) {    

         $variables.controlDetails.created_by = $application.user.username;
         $variables.controlDetails.updated_by = $application.user.username;

          if ($variables.controlDetails.OrganizationAssignmentId) {
            await Actions.fireDataProviderEvent(context, {
              update: {
                data: $variables.controlDetails,
                keys: $variables.controlDetails.OrganizationAssignmentId,
              },
              target: $variables.businessControlsADP,
            }, { id: 'E' });
          }
          else {
            $variables.controlDetails.OrganizationAssignmentId = $variables.businessControlsADP.data.length + 1;
            // $variables.controlDetails.line_num = $variables.businessControlsADP.data.length + 1;
            await Actions.fireDataProviderEvent(context, {
              add: {
                data: $variables.controlDetails,
                keys: $variables.controlDetails.OrganizationAssignmentId,
                indexes: 0,
              },
              target: $variables.businessControlsADP,
            });
          }
   
       
      }

      const lineDialogClose = await Actions.callComponentMethod(context, {
        selector: '#BUAccessDialog',
        method: 'close',
      });
    }
     }
  }

  return controlsDetailSaveChain;
});
