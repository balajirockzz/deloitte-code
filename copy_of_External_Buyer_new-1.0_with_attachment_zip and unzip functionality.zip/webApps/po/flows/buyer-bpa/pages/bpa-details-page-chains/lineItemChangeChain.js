define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

   

      // ---- TODO: Add your code here ---- //
      console.log(key);
      console.log(data);
      console.log(metadata);

      if(!data)
       data = metadata.detail.itemContext.data;

      $variables.lineDetails.Item = data.ItemNumber;
      $variables.lineDetails.ItemDescription = data.ItemDescription;
      // $variables.lineDetails.attribute1 = data.OrganizationCode;
      $variables.lineDetails.UOM = data.PrimaryUOMName;
      // $variables.lineDetails.organization_code = data.OrganizationCode;
      // $variables.lineDetails.line_type = data.InventoryItemFlag ? 'Goods':'Rate Based Services';
      $variables.lineDetails.LineNumber = $page.variables.requestLinesADP.data.length + 1;
      // $variables.lineDetails.item_description = data.item_description;

      const results = await Promise.all([
        async () => {

          const response2 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/getItems',
            uriParams: {
              expand: 'ItemCategories',
              q: "ItemNumber = '"+data.ItemNumber+"' and OrganizationCode= '"+data.OrganizationCode+"'",
              fields: 'ItemCategories',
            },
          });

          if (!response2.ok) {
            // if(response2.items.length >0 && response2.items[0].ItemCategories && response2.items[0].ItemCategories.items[0].CategoryName)
            // $variables.lineDetails.category_name = response2.items[0].ItemCategories.items[0].CategoryName; 
            // else
            // $variables.lineDetails.category_name = "Goods";

          }
        },
        async () => {

    let response =  await Actions.callRest(context, {
            endpoint: 'ics_conn/postSTP_PROC_INT_012_V1_1_0GetItemOneCost',
            body: {
              POReceive: {
                DocumentStyle: 'Dell-Standard Purchase Order',
                OrganizationCode: data.OrganizationCode,
                PartList: {
                  Part: [
              {
                      PartID:  data.ItemNumber,
                      Effective_Date: '25-01-2024',
                      VendorID: '10023',
                      VendorLoc: '10023',
                    },
            ],
                },
              },
            },
          });

          if (response.ok) {
             $variables.lineDetails.price = Number(response.body.POReceive.PartList.Part[0].PRICE);
          }
        },
      ].map(sequence => sequence()));

    }
  }

  return lineItemChangeChain;
});
