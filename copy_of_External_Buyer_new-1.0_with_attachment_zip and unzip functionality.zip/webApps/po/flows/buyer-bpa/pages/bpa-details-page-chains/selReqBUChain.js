define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class selReqBUChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application } = context;


      if(data){
       $flow.variables.transReqDetails.bill_to_location = data.BillToLocation;
       $flow.variables.transReqDetails.ship_to_location = data.ShipToLocation;
      }

      const response = await Actions.callRest(context, {
        endpoint: 'fscm/getInventoryOrganizations2',
        uriParams: {
          fields: 'LegalEntityName',
          q: "ManagementBusinessUnitName="+"'"+$flow.variables.transReqDetails.requisitioning_bu+"'",
        },
      });

      $flow.variables.transReqDetails.sold_to_legal_entity = response.body.items[0].LegalEntityName;
    }
  }

  return selReqBUChain;
});
