define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierSiteChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      let reqBuArray =[];

      if(!data)
      data = metadata.itemContext.data;

      if(data){
                        reqBuArray = $application.functions.filterADPData(
                  $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'REQUISITION_BU_ID'),['SUPPLIER_SITE_ID'],[data.SUPPLIER_SITE_ID])
        const results = await Promise.all([
          async () => {

                  const responseReqBU = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getSupplierAssignments',
        uriParams: {
          siteId: data.SUPPLIER_SITE_ID,
          supplierId: data.SUPPLIER_ID,
          q: 'ClientBUId in '+$application.functions.getInClause(
            reqBuArray,'REQUISITION_BU_ID'
          ),
        },
      });

            if (responseReqBU.ok) {
              $variables.RequisitionBuADP.data = responseReqBU.body.items;
              if(responseReqBU.body.items.length ===1){
                $variables.controlDetails.RequisitioningBUId = responseReqBU.body.items[0].ClientBUId;
                $variables.controlDetails.BillToBUId = responseReqBU.body.items[0].BillToBUId;
                $variables.controlDetails.ShipToLocationId = responseReqBU.body.items[0].ShipToLocationId;
                $variables.controlDetails.BillToLocationId = responseReqBU.body.items[0].BillToLocationId;
                 $variables.controlDetails.RequisitioningBU = responseReqBU.body.items[0].ClientBU;
                $variables.controlDetails.BillToBU = responseReqBU.body.items[0].BillToBU;
                $variables.controlDetails.ShipToLocation = responseReqBU.body.items[0].ShipToLocation;
                $variables.controlDetails.BillToLocation = responseReqBU.body.items[0].BillToLocation;
              
              }
               
            }
            
          },
          async () => {
          
                  const responseReqBU = await Actions.callRest(context, {
                    endpoint: 'fscm_conn/getSupplierAssignments',
                    uriParams: {
                      siteId: data.SUPPLIER_SITE_ID,
                      supplierId: data.SUPPLIER_ID,
                    },
                  });
          
            if (responseReqBU.ok) {
              
              $variables.billToBUADP.data = responseReqBU.body.items;
              
            }
            
          },
          async () => {

            $flow.variables.transReqDetails.SupplierSite = data.SUPPLIER_SITE;

                  const response = await Actions.callRest(context, {
                    endpoint: 'fscm_conn/getSupplierSite',
                    uriParams: {
                      supplierId: data.SUPPLIER_ID,
                      siteId: data.SUPPLIER_SITE_ID,
                    },
                  });
              
                      if (response.ok) {                
                        data = response.body;

      // $flow.variables.transReqDetails.SupplierSite = data? data.SupplierSite:null;
       $flow.variables.transReqDetails.SupplierCommunicationMethodCode = data.CommunicationMethodCode  ? data.CommunicationMethod:null;
       $flow.variables.transReqDetails.SupplierEmailAddress = data.Email  ? data.Email:null;
       $flow.variables.transReqDetails.PaymentTerms = data.PaymentTerms ? data.PaymentTerms:null;
       $flow.variables.transReqDetails.CurrencyCode =data.InvoiceCurrencyCode ? data.InvoiceCurrencyCode:( data.PaymentCurrencyCode? data.PaymentCurrencyCode  :'US Dollar');               $flow.variables.transReqDetails.SupplierSite = data.SupplierSite;
                      }
          },
        ].map(sequence => sequence()));


      //  $variables.controlDetails.purchasingsite = data.SupplierSiteId;

    }



  
    }
  }

  return supplierSiteChain;
});
