define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class suppliersiteValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

  if(!data)
      data = metadata.itemContext.data;

      if(data){

      $flow.variables.transReqDetails.SupplierSite = data? data.SupplierSite:null;
      // $flow.variables.transReqDetails.budget_period_id=null;
      //  $flow.variables.transReqDetails.control_budget_id=null;
       $flow.variables.transReqDetails.SupplierCommunicationMethodCode = data.CommunicationMethod  ? data.CommunicationMethod:null;
       $flow.variables.transReqDetails.SupplierEmailAddress = data.Email  ? data.Email:null;
       $flow.variables.transReqDetails.PaymentTerms = data.PaymentTerms ? data.PaymentTerms:null;
       $flow.variables.transReqDetails.CurrencyCode =data.InvoiceCurrencyCode ? data.InvoiceCurrencyCode:( data.PaymentCurrencyCode? data.PaymentCurrencyCode  :'US Dollar');
       $flow.variables.transReqDetails.Currency = data.InvoiceCurrency ? data.InvoiceCurrency: (data.PaymentCurrency? data.PaymentCurrency :'US Dollar');
      $variables.controlDetails.purchasingsite = data.SupplierSiteId;

    }

      const responseReqBU = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getSupplierAssignments',
        uriParams: {
          siteId: data.SupplierSiteId,
          supplierId: $flow.variables.transReqDetails.SupplierId,
        },
      });

      $page.variables.RequisitionBuADP.data = responseReqBU.body.items;

    }
  }

  return suppliersiteValueItemChangeChain;
});
