define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class buyerDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.details 
     * @param {string} params.deleteFlag 
     */
    async run(context, { details, deleteFlag = 'N' }) {
      const { $page, $flow, $application, $constants, $variables } = context;
     
      await $application.functions.openSpinnerDialog();

      if (deleteFlag === 'Y') {
        await Actions.fireDataProviderEvent(context, {
          remove: {
            data: details,
            keys: details.PERSON_ID,
          },
          target: $variables.AddBuyerADP,
        });
      }
      else{

     if($variables.lineDetails.CREATED_BY ){



      await Actions.fireDataProviderEvent(context, {
        target: $variables.AddBuyerADP,
        update: {
          data: details,
          keys: details.PERSON_ID,
        },
      });
         
     }
     else{
              // $variables.lineDetails.CREATED_BY = $application.user.username;
              // $variables.lineDetails.ASSOCIATION_ID = $variables.mappingDetailsADP.data.length +1;

     await Actions.fireDataProviderEvent(context, {
            add: {
              data: details,
              keys: details.PERSON_ID,
              indexes: 0,
            },
            target: $variables.AddBuyerADP,
          });
     }
      }

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.buyerVal',
  ],
      });

      await $application.functions.closeSpinnerDialog();

     }
  }

  return buyerDetailSaveChain;
});
