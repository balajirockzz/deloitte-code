define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class disableBuyerChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.row 
     * @param {boolean} params.value 
     */
    async run(context, { row, value }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.lineDetails = row;
      $variables.lineDetails.ENABLED_FLAG = value;
      $variables.lineDetails.CREATED_BY = $application.user.username;

      await Actions.callChain(context, {
        chain: 'buyerDetailSaveChain',
        params: {
          details: $variables.lineDetails,
        },
      });
    }
  }

  return disableBuyerChain;
});
