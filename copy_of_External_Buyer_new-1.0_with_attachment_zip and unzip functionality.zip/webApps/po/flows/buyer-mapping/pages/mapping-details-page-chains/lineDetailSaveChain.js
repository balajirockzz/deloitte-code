define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.lineId 
     * @param {string} params.deleteFlag 
     */
    async run(context, { lineId, deleteFlag = 'N' }) {
      const { $page, $flow, $application, $constants, $variables } = context;
     
      await $application.functions.openSpinnerDialog();
      let isValid = true;

      if (deleteFlag === 'Y') {
        await Actions.fireDataProviderEvent(context, {
          remove: {
          data: $variables.lineDetails,
          keys: $variables.lineDetails.ASSOCIATION_ID,
          },
          target: $variables.mappingDetailsADP,
        });
      }
      else{

        if( $application.functions.isFormValid('line_form')){

       

     if($variables.lineDetails.CREATED_BY ){



      await Actions.fireDataProviderEvent(context, {
        target: $variables.mappingDetailsADP,
        update: {
          data: $variables.lineDetails,
          keys: $variables.lineDetails.ASSOCIATION_ID,
        },
      });
         
     }
    
 
     else{
              // $variables.lineDetails.CREATED_BY = $application.user.username;
              $variables.lineDetails.ASSOCIATION_ID = $variables.mappingDetailsADP.data.length +1;

     await Actions.fireDataProviderEvent(context, {
            add: {
              data: $variables.lineDetails,
              keys: $variables.lineDetails.ASSOCIATION_ID,
              indexes: 0,
            },
            target: $variables.mappingDetailsADP,
          });
     }
        }  
         else{
       isValid = false;
     }

       
      }


      if(isValid){
      const lineDialogClose = await Actions.callComponentMethod(context, {
      selector: '#lineDialog',
      method: 'close',
      });
      }

      await $application.functions.closeSpinnerDialog();
     }
  }

  return lineDetailSaveChain;
});
