define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierSiteChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if(!data)
      data = metadata.itemContext.data;

      if(data){

      $flow.variables.transReqDetails.supplier_site = data? data.SupplierSite:null;
      // $flow.variables.transReqDetails.budget_period_id=null;
      //  $flow.variables.transReqDetails.control_budget_id=null;
       $flow.variables.transReqDetails.communication_method = data? data.CommunicationMethod:null;
       $flow.variables.transReqDetails.currency_code =data.InvoiceCurrencyCode ? data.InvoiceCurrencyCode:( data.PaymentCurrencyCode? data.PaymentCurrencyCode  :'US Dollar');
       $flow.variables.transReqDetails.functional_currency = data.InvoiceCurrency ? data.InvoiceCurrency: (data.PaymentCurrency? data.PaymentCurrency :'US Dollar');
    }

      const responseReqBU = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getSupplierAssignments',
        uriParams: {
          siteId: data.SupplierSiteId,
          supplierId: $variables.lineDetails.SUPPLIER_ID,
        },
      });

      $page.variables.RequisitionBuADP.data = responseReqBU.body.items;
    }
  }

  return supplierSiteChain;
});
