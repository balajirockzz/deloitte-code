define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class doRequestChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.headerId 
     * @param {string} params.action 
     */
    async run(context, { headerId, action }) {
      const { $flow, $application } = context;

      if (action === 'DELETE') {
        const response = await Actions.callRest(context, {
          endpoint: 'ords_conn/deletePO',
          uriParams: {
            id: headerId,
          },
        });

        if (response.ok) {

          await Actions.fireNotificationEvent(context, {
            displayMode: 'transient',
            type: 'confirmation',
            summary: 'Deleted the request ',
          });
        }
      }
    }
  }

  return doRequestChain;
});
