define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CancelPOLineActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

      if ($variables.createdPOlineBy === $application.user.username) {
        await Actions.fireNotificationEvent(context, {
          summary: JSON.stringify($variables.createdPOlineBy),
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'This line cannot be cancelled',
        });
      } else {
      

      const payload = await $functions.cancelPOLine($variables.CancelPoLineKey);

        $variables.CancelLinesADP.data = payload;

      // const response = await Actions.callRest(context, {
      //   endpoint: 'fscm_conn/patchDraftPurchaseOrdersDraftPurchaseOrdersUniqID',
      //   uriParams: {
      //     draftPurchaseOrdersUniqID: $flow.variables.transReqDetails.POHeaderId,
      //   },
      //   body: payload,
      // });

      // if (response.ok) {
      //   await Actions.fireNotificationEvent(context, {
      //     summary: 'PO Line cancelled.',
      //     type: 'info',
      //     displayMode: 'transient',
      //   });

      //   await $application.functions.closeSpinnerDialog();
      
      //   return;
      // } else {
      //   await Actions.fireNotificationEvent(context, {
      //     summary: 'Api Error!',
      //   });
      // }
      }
      await $application.functions.closeSpinnerDialog();
    }
  }

  return CancelPOLineActionChain;
});
