/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class Headerandlinepoattachment extends ActionChain {

    /**
     * Submit form data
     * @param {Object} context
     */
    async run(context) {
      const { $page, $variables, $flow } = context;

      await Actions.fireNotificationEvent(context, {
        summary: $variables.po_attachmentHeader.fileType,
      });

    //  if ($variables.po_attachmentHeader.fileType  === 'application/zip') {
if(1===1){
        const results = await Promise.all([
          async () => {

            let payload = {
  OperationName: 'uploadFileToUCM',
  DocumentContent: $variables.po_attachmentHeader.fileContent,
  DocumentAccount: 'prc$/purchaseOrder$/import$',
  ContentType: 'zip',
  FileName: $variables.po_attachmentHeader.fileName,
  DocumentId: null,
};

            // ---- TODO: Add your code here ---- //
            console.log('testtestinhggggg',payload);

            const response = await Actions.callRest(context, {
              endpoint: 'UploadFileToUCM/postFscmRestApiResources11_13_18_05Erpintegrations2',
              body: payload,
            });

            if (!response.ok) {
              await Actions.fireNotificationEvent(context, {
                summary: 'Error while loading to ucm',
                displayMode: 'persist',
                type: 'error',
              });
            } else {
              $variables.po_attachmentHeader.fileURL = "https://iawmqy-dev2.fa.ocs.oraclecloud.com/cs/idcplg?IdcService=GET_FILE&dID=" + response.body.DocumentId;

              await Actions.fireNotificationEvent(context, {
                summary: $variables.po_attachmentHeader.fileURL,
                displayMode: 'transient',
                type: 'info',
              });


              // let payloadhdr = {
              //   "ChangeOrderDescription": "change order",
              //   "ChangeOrderInitiatingParty": "BUYER",
              //   "DFF": {
              //     "items": [
              //       {
              //         "PoHeaderId": 300000105843281,
              //         "__FLEX_Context": "Dell-BSOM Purchase Order",
              //         "__FLEX_Context_DisplayValue": "Dell-BSOM Purchase Order",
              //         "attachment": $variables.po_attachmentHeader.fileURL,
              //         "customerCode": null
              //       }
              //     ]
              //   }
              // };

              //           // ---- TODO: Add your code here ---- //
              // console.log('payloadforthedff',payloadhdr);

              // const response2 = await Actions.callRest(context, {
              //   endpoint: 'UploadFileToUCM/patchFscmRestApiResources11_13_18_05DraftPurchaseOrdersHeader_id',
              //   body: payloadhdr,
              //   uriParams: {
              //     'header_id': 300000105843281,
              //   },
              // });

              // if (!response2.ok) {
              //   await Actions.fireNotificationEvent(context, {
              //     summary: 'Error in Uploading Header',
              //     displayMode: 'persist',
              //     type: 'error',
              //   });
              // } else {
              //   await Actions.fireNotificationEvent(context, {
              //     summary: 'Header Attachment Successfully',
              //     displayMode: 'transient',
              //     type: 'info',
              //   });

              //   const response3 = await Actions.callRest(context, {
              //     endpoint: 'UploadFileToUCM/postFscmRestApiResources11_13_18_05DraftPurchaseOrdersDraftActionSubmit',
              //     uriParams: {
              //       draftPurchaseOrdersUniqID: 300000105843281,
              //     },
              //   });

              //   if (!response3.ok) {
              //     await Actions.fireNotificationEvent(context, {
              //       summary: 'Error While Submitting',
              //       displayMode: 'persist',
              //       type: 'error',
              //     });
              //   } else {
              //     await Actions.fireNotificationEvent(context, {
              //       summary: 'Submitted Successfully',
              //       displayMode: 'transient',
              //       type: 'info',
              //     });
              //   }
              // }
            }
          },
          async () => {

            const results2 = await ActionUtils.forEach($variables.Line_adp.data, async (item, index) => {

              if (item.fileContent !== 'undefined') {

                let  linepayload = {
  OperationName: 'uploadFileToUCM',
  DocumentContent: item.fileContent,
  DocumentAccount: 'prc$/purchaseOrder$/import$',
  ContentType: 'zip',
  FileName: item.fileName,
  DocumentId: null,
};

                // ---- TODO: Add your code here ---- //
                console.log('dshdbsdsadasjdjsadsa',linepayload);

                const response4 = await Actions.callRest(context, {
                  endpoint: 'UploadFileToUCM/postFscmRestApiResources11_13_18_05Erpintegrations2',
                  body: linepayload,
                });

                $variables.po_attachmentLine_contents.LineNumber = item.LineNumber;
                $variables.po_attachmentLine_contents.FileName = item.FileName;
                $variables.po_attachmentLine_contents.fileURL = "https://iawmqy-dev2.fa.ocs.oraclecloud.com/cs/idcplg?IdcService=GET_FILE&dID=" + response4.body.DocumentId;

                  await Actions.fireDataProviderEvent(context, {
                add: {
                  data: $variables.po_attachmentLine_contents,
                  keys: $variables.po_attachmentLine_contents.LineNumber,
                  indexes: 0,
                },
                target: $variables.Line_adp_content,
            });

                const results3 = await ActionUtils.forEach($variables.Line_adp_content.data, async (items, indexes) => {

                  await Actions.fireNotificationEvent(context, {
                    summary: items.fileURL,
                  });

                   let payloadline={
                "ChangeOrderDescription": "change order",
                "ChangeOrderInitiatingParty": "BUYER",
                
                "lines": [
                    {
              "POLineId": 300000096950239,
                   
              "DFF": [
                  {
                      
                      "lineComments": items.fileURL
                      
                  }
              ]
                    }
                ]
            };



                }, { mode: 'serial' });
              }



                  
 }, { mode: 'serial' });
          },
        ].map(sequence => sequence()));

        

      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Please Upload Only Zip File',
          displayMode: 'persist',
          type: 'error',
        });
      }
    }
  }

  return Headerandlinepoattachment;
});
