define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await $application.functions.openSpinnerDialog();

      // new
      await Actions.callChain(context, {
        chain: 'Headerandlinepoattachment',
      });

      const createPayloadattachment = await $functions.createPayloadattachment($flow.variables.transReqDetails, $variables.requestLinesADP.data, $variables.Line_adp_content.data, $variables.po_attachmentHeader.fileURL);
      console.log(createPayloadattachment);
       let lines = $page.variables.requestLinesADP.data;

      // $flow.variables.transReqDetails.lines.items = $variables.requestLinesADP.data;

      // if ($application.functions.isFormValid('hdr_form') && lines.length >0) {
      

      if ($flow.variables.transReqDetails.POHeaderId) {



    // Create a set of POLineIds from cancelLinesData for quick lookup
    let cancelLineIds = new Set($variables.CancelLinesADP.data.map(line => line.POLineId));

    // Filter out lines from requestLinesData that have a matching POLineId in cancelLinesData
    let filteredRequestLinesData = $variables.requestLinesADP.data.filter(line => !cancelLineIds.has(line.POLineId));

     let linesCombine = $variables.CancelLinesADP.data.concat(filteredRequestLinesData);



    console.log(linesCombine);


        // new
        const createchangeOrderPayloadnew = await $functions.createchangeOrderPayloadnew($flow.variables.transReqDetails, linesCombine, $variables.Line_adp_content.data, $variables.po_attachmentHeader.fileURL);
console.log(createchangeOrderPayloadnew);
        const createPayload1 = await $functions.createchangeOrderPayload($flow.variables.transReqDetails, linesCombine);
        

        // new
        const response = await Actions.callRest(context, {
          endpoint: 'fscm_conn/patchDraftPurchaseOrdersDraftPurchaseOrdersUniqID',
          body: createchangeOrderPayloadnew,
          uriParams: {
            draftPurchaseOrdersUniqID: $flow.variables.transReqDetails.POHeaderId,
          },
        });

        // const response3 = await Actions.callRest(context, {
        //   endpoint: 'fscm_conn/patchDraftPurchaseOrdersDraftPurchaseOrdersUniqID',
        //   body: createPayload1,
        //   uriParams: {
        //     draftPurchaseOrdersUniqID: $flow.variables.transReqDetails.POHeaderId,
        //   },
        // });

        if (!response.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Rest api error!',
          });
        
          return;
        }

        // new
        const createlinePayload = await $functions.createlinePayload($flow.variables.transReqDetails, $variables.requestLinesADP.data, $variables.Line_adp_content.data);

        let linedetailsbodyarray = [];
        linedetailsbodyarray = createlinePayload;


               if (response.ok) {

        

        const results = await ActionUtils.forEach(linedetailsbodyarray.lines, async (item, index) => {

          const response4 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/addLineToPurchaseOrder',
            uriParams: {
              draftPurchaseOrdersUniqID: $flow.variables.transReqDetails.POHeaderId,
            },
            body: item,
          });

          if (!response4.ok) {
             $variables.checkFlag = true;
          
            return;
          }

        }, { mode: 'serial' });

        if ($variables.checkFlag === true) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Rest Api error, cannot add line.',
          });
        }
        }
        if (response.ok && $variables.checkFlag !== true) {
          const response2 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/submitDraftPurchaseOrder',
            uriParams: {
              draftPurchaseOrdersUniqID: response.body.POHeaderId,
            },
          });

          await Actions.fireNotificationEvent(context, {
            summary: "PO Updated with number : "+ response.body.OrderNumber,
            displayMode: 'transient',
            type: 'info',
          });

          const toPoSearch = await Actions.navigateToPage(context, {
            page: 'po-search',
          });
       }
      } else {

        const createPayload1 = await $functions.createPayload($flow.variables.transReqDetails, $variables.requestLinesADP.data);

        // new
        const createPayloadattachment2 = await $functions.createPayloadattachment($flow.variables.transReqDetails, $variables.requestLinesADP.data, $variables.Line_adp_content.data, $variables.po_attachmentHeader.fileURL);
          const response = await Actions.callRest(context, {
                  endpoint: 'fscm_conn/postDraftPurchaseOrders',
                  body: createPayloadattachment2,
                });

        // const response = await Actions.callRest(context, {
        //   endpoint: 'fscm_conn/postDraftPurchaseOrders',
        //   body: createPayload1,
        // });
              

        if (response.ok) {
          const response2 = await Actions.callRest(context, {
            endpoint: 'fscm_conn/submitDraftPurchaseOrder',
            uriParams: {
              draftPurchaseOrdersUniqID: response.body.POHeaderId,
            },
          });

          await Actions.fireNotificationEvent(context, {
            summary: "PO Created with number : "+ response.body.OrderNumber,
            displayMode: 'transient',
            type: 'info',
          });

          const toPoSearch = await Actions.navigateToPage(context, {
            page: 'po-search',
          });
       }
      }
      // } else {
      //   await Actions.fireNotificationEvent(context, {
      //     displayMode: 'transient',
      //     summary: 'Missing required fields'+(lines.length < 1? ': Atleast One Item Details is mandatory':''),
      //   });
      // }
      await $application.functions.closeSpinnerDialog();
    }
  }

  return SubmitActionChain;
});
