define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class lineDetailSaveChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.lineId 
     */
    async run(context, { lineId }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if ($application.functions.isFormValid('line_form')) {
     

      if (lineId) {
                  
           $variables.po_attachmentLine.LineNumber =  $variables.lineDetails.LineNumber;


        await Actions.fireDataProviderEvent(context, {
          target: $variables.requestLinesADP,
          remove: {
            data: lineId,
            keys: lineId.POLineId,
          },
        });

          // new
          await Actions.fireDataProviderEvent(context, {
          add: {
            data: $variables.po_attachmentLine,
            keys: $variables.po_attachmentLine.LineNumber,
            indexes: 0,
          },
          target: $variables.Line_adp,
                      });
      } else {

        if ($application.functions.isFormValid('line_form')) {    

             $variables.lineDetails.CreatedBy = $application.user.username;
         $variables.lineDetails.LastUpdatedBy = $application.user.username;

          if ($variables.lineDetails.POLineId) {
           $variables.po_attachmentLine.LineNumber =  $variables.lineDetails.LineNumber;

            await Actions.fireDataProviderEvent(context, {
              update: {
                data: $variables.lineDetails,
                keys: $variables.lineDetails.POLineId,
              },
              target: $variables.requestLinesADP,
            });

              // new
              await Actions.fireDataProviderEvent(context, {
              add: {
                data: $variables.po_attachmentLine,
                keys: $variables.po_attachmentLine.LineNumber,
                indexes: 0,
              },
              target: $variables.Line_adp,
                          });
          }
          else {

           // $variables.lineDetails.POLineId = $variables.requestLinesADP.data.length + 1;
             $variables.lineDetails.LineNumber = $variables.requestLinesADP.data.length + 1;
             $variables.po_attachmentLine.LineNumber = $variables.Line_adp.data.length + 1;

            await Actions.fireDataProviderEvent(context, {
              add: {
                data: $variables.lineDetails,
                keys: $variables.lineDetails.POLineId,
                indexes: 0,
              },
              target: $variables.requestLinesADP,
            });

            // new
            await Actions.fireDataProviderEvent(context, {
              add: {
                data: $variables.po_attachmentLine,
                keys: $variables.po_attachmentLine.LineNumber,
                indexes: 0,
              },
              target: $variables.Line_adp,
            });

              // new
              await Actions.resetVariables(context, {
                variables: [
    '$page.variables.po_attachmentLine',
  ],
              });
          }
        }
       
      }

        await Actions.resetVariables(context, {
          variables: [
    '$page.variables.disableItemFlag',
  ],
        });

      const lineDialogClose = await Actions.callComponentMethod(context, {
        selector: '#lineDialog',
        method: 'close',
      });
    }
     }
  }

  return lineDetailSaveChain;
});
