define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierSiteChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {any} params.data 
     * @param {any} params.metadata 
     */
    async run(context, { key, data, metadata }) {
      const { $page, $flow, $application, $constants, $variables } = context;


        let reqBuArray =[];

      if(!data)
      data = metadata.itemContext.data;

      if(data){

                                reqBuArray = $application.functions.filterADPData(
                  $application.functions.getADPData($application.variables.buyerAssoc.ASSOCIATIONS,'SUPPLIER_SITE_ID'),['SUPPLIER_SITE_ID'],[data.SUPPLIER_SITE_ID])

      $flow.variables.transReqDetails.SupplierSite = data? data.SUPPLIER_SITE:null;
      // $flow.variables.transReqDetails.budget_period_id=null;
      //  $flow.variables.transReqDetails.control_budget_id=null;
       $flow.variables.transReqDetails.SupplierCommunicationMethod = data? data.CommunicationMethod:null;
       $flow.variables.transReqDetails.CurrencyCode =data.InvoiceCurrencyCode ? data.InvoiceCurrencyCode:( data.PaymentCurrencyCode? data.PaymentCurrencyCode  :'US Dollar');
       $flow.variables.transReqDetails.Currency = data.InvoiceCurrency ? data.InvoiceCurrency: (data.PaymentCurrency? data.PaymentCurrency :'US Dollar');
    }

      // const responseReqBU = await Actions.callRest(context, {
      //   endpoint: 'fscm_conn/getSupplierAssignments',
      //   uriParams: {
      //     siteId: data.SUPPLIER_SITE_ID,
      //     supplierId: $flow.variables.transReqDetails.SupplierId,
      //   },
      // });

    const responseReqBU = await Actions.callRest(context, {
        endpoint: 'fscm_conn/getSupplierAssignments',
        uriParams: {
          siteId: data.SUPPLIER_SITE_ID,
          supplierId: data.SUPPLIER_ID,
          q: 'ClientBUId in '+$application.functions.getInClause(
            reqBuArray,'REQUISITION_BU_ID'
          ),
        },
      });

      $page.variables.RequisitionBuADP.data = responseReqBU.body.items;
    }
  }

  return supplierSiteChain;
});
