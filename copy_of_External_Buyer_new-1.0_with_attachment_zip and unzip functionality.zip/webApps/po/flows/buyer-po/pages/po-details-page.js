define([], () => {
  'use strict';

  class PageModule {

    generateBIPReportREqPayload(po_number){
let payload =`<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
   <soap:Header/>
   <soap:Body>
      <pub:runReport>
         <pub:reportRequest>
            <pub:attributeFormat>csv</pub:attributeFormat>
            <pub:parameterNameValues>
               <pub:item>
                  <pub:name>p_po_number</pub:name>
                  <pub:values>
                     <pub:item>`+po_number+`</pub:item>
                  </pub:values>
               </pub:item>
            </pub:parameterNameValues>
            <pub:reportAbsolutePath>/Custom/Extension/STP/STP_PROC_EXT_005_External_Buyer_PO_ActionHistory_Report.xdo</pub:reportAbsolutePath>
            <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
         </pub:reportRequest>
      </pub:runReport>
   </soap:Body>
</soap:Envelope>`;

return payload;

}









      }

  PageModule.prototype.filterADPData = function (arrayList,attrs,vals) {
      let returnVal =[];
      let arrayItem =[];

      if(!attrs || attrs.length <1)
      returnVal =arrayList; 
      else{
      arrayList.forEach((item) => {
        let isMatched = false;
        attrs.forEach( (attr,i)=>{
          if(item[attr] === vals[i])
          isMatched = true;
        });
        if(isMatched)
        returnVal.push(item);
      }
      );}
     return returnVal;
    };

     PageModule.prototype.isCrossDivision = function (linesData) {
      let returnVal = 'Y';
      linesData.forEach(element => {
        if(element.from_division !== element.to_division){
          returnVal = 'N';
        }
      });
         return returnVal;
    };

 PageModule.prototype.createPayloadattachment = function (data, LineADP, lineAttachments,headerFileURL) {
  console.log("LineADP data:", JSON.stringify(LineADP));

  const lines = LineADP.map((line) => {
    // Find matching attachment for the current line
    const attachment = lineAttachments.find(att => att.LineNumber === line.LineNumber);
    console.log(JSON.stringify(lineAttachments)+"attachmentlele");
    console.log(lineAttachments.LineNumber+"attachmentlinenumebr");
    console.log(line.LineNumber+"linenumberlineevel");


    const fileUrl = attachment && attachment.fileURL ? attachment.fileURL : null;
    console.log(fileUrl);
//line
    return {
      LineNumber: line.LineNumber,
      LineType: "Goods",
      Item: line.Item,
      Category: "Goods",
      Description: line.Description || "Peripherals_Type_Docking Stations",
      Quantity: line.Quantity,
      Price: line.Price,
      UOM: line.UOM,
      //dff there means we have to enter here or in other places (for lines)
"DFF": [
                {
                  "__FLEX_Context" : data.DocumentStyle,
                  "__FLEX_Context_DisplayValue" : data.DocumentStyle,
                  "attachment" : fileUrl,

                }
            ],
                  schedules: [
        {
          ScheduleNumber: line.LineNumber,
          Quantity: line.Quantity,
          ShipToLocation: data.ShipToLocationCode,
          ShipToOrganizationCode: line.OrganizationCode,
          ReceiptCloseTolerancePercent: 0,
          InvoiceMatchOptionCode: "P",
          RequestedDeliveryDate: line.RequestedDeliveryDate,
          PromisedDeliveryDate: line.PromisedDeliveryDate,
          InvoiceCloseTolerancePercent: 0,
          InspectionRequiredFlag: true,
          ReceiptRequiredFlag: false,
          ReceiptRoutingId: 3,
          distributions: [
            {
              DistributionNumber: line.LineNumber,
              DeliverToLocation: data.ShipToLocationCode,
              Quantity: line.Quantity,
            }
          ]
        }
      ]
    };
  });
//header
  return {
    ProcurementBUId: data.ProcurementBUId,
    RequisitioningBUId: data.RequisitioningBUId,
    BuyerId: data.BuyerId,
    Supplier: data.Supplier,
    Currency: data.Currency || "USD",
    DocumentStyleId: data.DocumentStyleId,
    SupplierSiteId: data.SupplierSiteId,
    BillToLocation: data.BillToLocation,
    DefaultShipToLocation: data.ShipToLocationCode,
    RequiredAcknowledgment: data.RequiredAcknowledgment || "None",
    Description: data.Description || null,
    SupplierCommunicationMethod: data.SupplierCommunicationMethodCode,
    SupplierEmailAddress: data.SupplierEmailAddress,
    BuyerManagedTransportFlag: data.BuyerManagedTransportFlag || false,
    PayOnReceiptFlag: data.PayOnReceiptFlag || false,
    PaymentTerms: data.PaymentTerms,
    ShippingMethod: data.ShippingMethod || "",
    FreightTermsCode: data.FreightTermsCode || null,
    FOBCode: data.FOBCode || null,
    NoteToReceiver:  data.NoteToReceiver ? data.NoteToReceiver +" "+ headerFileURL : headerFileURL || "",
    NoteToSupplier: data.NoteToSupplier || "",
    // for header
    // "DFF": [
    //             {
    //                 "lineComments": fileUrl,
    //             }
    //         ],
    lines: lines
  };
};

// PageModule.prototype.createPayloadattachment = function (data, LineADP, lineAttachmentArray) {

//   console.log("LineADP data:", JSON.stringify(LineADP));
//   console.log("lineAttachmentArray data:", JSON.stringify(lineAttachmentArray));

//   // const lines = LineADP.map((line) => {
//     // Find the attachment URL for the current line number
//     // const attachment = lineAttachmentArray.find(att => att.LineNumber === line.LineNumber);
//     // const attachmentUrl = attachment ? attachment.fileURL : null;
//   const attachmentMap = new Map();
//   lineAttachmentArray.forEach(att => {
//     attachmentMap.set(att.LineNumber, att.fileURL);
//   });

//   const lines = LineADP.map((line) => {
//     // Get the attachment URL for the current line number from the map
//     const attachmentUrl = attachmentMap.get(line.LineNumber) || null;
//     console.log("attachemny"+attachmentUrl);

//     return {
//       LineNumber: line.LineNumber, 
//       LineType:  "Goods", 
//       Item: line.Item , 
//       Category: "Goods", 
//       Description: line.Description || "Peripherals_Type_Docking Stations",
//       Quantity: line.Quantity,
//       Price: line.Price,
//       UOM: line.UOM , 
//       "DFF": [
//         {
//           "lineComments": attachmentUrl
//         }
//       ],
//       schedules: [
//         {
//           ScheduleNumber: line.LineNumber, 
//           Quantity: line.Quantity, 
//           ShipToLocation: data.ShipToLocationCode , 
//           ShipToOrganizationCode: line.OrganizationCode, 
//           ReceiptCloseTolerancePercent: 0, 
//           InvoiceMatchOptionCode: "P", 
//           RequestedDeliveryDate: line.RequestedDeliveryDate,
//           PromisedDeliveryDate: line.PromisedDeliveryDate,
//           // EarlyReceiptToleranceDays: 0,  
//           InvoiceCloseTolerancePercent: 0,  
//           // LateReceiptToleranceDays: 0,  
//           // AccrueAtReceiptFlag: true,  
//           InspectionRequiredFlag: true,  
//           ReceiptRequiredFlag: false,  
//           ReceiptRoutingId: 3,
//           // DestinationTypeCode: "INVENTORY",  
//           // Carrier: null,  
//           // RequestedDeliveryDate: "",  
//           distributions: [
//             {
//               DistributionNumber: line.LineNumber, 
//               DeliverToLocation: data.ShipToLocationCode, 
//               Quantity: line.Quantity, 
//             }
//           ]
//         }
//       ]
//     };
//   });

//   // full payload structure
//   return {
//     ProcurementBUId: data.ProcurementBUId ,
//     RequisitioningBUId: data.RequisitioningBUId ,
//     BuyerId: data.BuyerId ,
//     Supplier: data.Supplier ,
//     Currency: data.Currency || "USD",
//     DocumentStyleId : data.DocumentStyleId,
//     SupplierSiteId: data.SupplierSiteId ,
//     BillToLocation: data.BillToLocation ,
//     DefaultShipToLocation: data.ShipToLocationCode ,
//     RequiredAcknowledgment: data.RequiredAcknowledgment || "None",
//     Description: data.Description || null,
//     SupplierCommunicationMethod: data.SupplierCommunicationMethodCode ,
//     SupplierEmailAddress: data.SupplierEmailAddress ,
//     // SupplierContactId : data.SupplierContactId,
//     BuyerManagedTransportFlag: data.BuyerManagedTransportFlag || false,
//     PayOnReceiptFlag: data.PayOnReceiptFlag || false,
//     PaymentTerms: data.PaymentTerms ,
//     ShippingMethod: data.ShippingMethod || "",
//     FreightTermsCode: data.FreightTermsCode || null,
//     FOBCode: data.FOBCode || null,
//     NoteToReceiver: data.NoteToReceiver || "",
//     NoteToSupplier: data.NoteToSupplier || "",
//     lines: lines // Dynamically created lines based on LineADP
//   };
// };


PageModule.prototype.createPayload = function (data, LineADP) {
  console.log("LineADP data:", JSON.stringify(LineADP));

 
  const lines = LineADP.map((line) => {
    
    return {
 
      LineNumber: line.LineNumber, 
      LineType:  "Goods", 
      Item: line.Item , 
      Category: "Goods", 
      Description: line.Description || "Peripherals_Type_Docking Stations",
      Quantity: line.Quantity,
      Price: line.Price,
      UOM: line.UOM , 
      schedules: [
        {
          ScheduleNumber: line.LineNumber, 
          Quantity: line.Quantity, 
          ShipToLocation: data.ShipToLocationCode , 
          ShipToOrganizationCode: line.OrganizationCode, 
          ReceiptCloseTolerancePercent: 0, 
          InvoiceMatchOptionCode: "P", 
          RequestedDeliveryDate: line.RequestedDeliveryDate,
          PromisedDeliveryDate: line.PromisedDeliveryDate,
         // EarlyReceiptToleranceDays: 0,  
          InvoiceCloseTolerancePercent: 0,  
         // LateReceiptToleranceDays: 0,  
         // AccrueAtReceiptFlag: true,  
          InspectionRequiredFlag: true,  
          ReceiptRequiredFlag: false,  
          ReceiptRoutingId: 3,
          //DestinationTypeCode: "INVENTORY",  
          //Carrier: null,  
         // RequestedDeliveryDate: "",  
          distributions: [
            {
              DistributionNumber: line.LineNumber, 
              DeliverToLocation: data.ShipToLocationCode, 
              Quantity: line.Quantity, 
            }
          ]
        }
      ]
    };
    
  });

  // full payload structure
  return {

    ProcurementBUId: data.ProcurementBUId ,
    RequisitioningBUId: data.RequisitioningBUId ,
    BuyerId: data.BuyerId ,
    Supplier: data.Supplier ,
    Currency: data.Currency || "USD",
    DocumentStyleId : data.DocumentStyleId,
    SupplierSiteId: data.SupplierSiteId ,
    BillToLocation: data.BillToLocation ,
    DefaultShipToLocation: data.ShipToLocationCode ,
    RequiredAcknowledgment: data.RequiredAcknowledgment || "None",
    Description: data.Description || null,
    SupplierCommunicationMethod: data.SupplierCommunicationMethodCode ,
    SupplierEmailAddress: data.SupplierEmailAddress ,
    //SupplierContactId : data.SupplierContactId,
    BuyerManagedTransportFlag: data.BuyerManagedTransportFlag || false,
    PayOnReceiptFlag: data.PayOnReceiptFlag || false,
    PaymentTerms: data.PaymentTerms ,
    ShippingMethod: data.ShippingMethod || "",
    FreightTermsCode: data.FreightTermsCode || null,
    FOBCode: data.FOBCode || null,
    NoteToReceiver: data.NoteToReceiver || "",
    NoteToSupplier: data.NoteToSupplier || "",
    lines: lines // Dynamically created lines based on LineADP
  };
};





PageModule.prototype.createchangeOrderPayloadnew = function (data, LineADP, lineAttachments,headerFileURL) {
  console.log("LineADP data:", JSON.stringify(LineADP));

//  const filteredLines = LineADP.filter(line => line.POLineId);
//   const lines = filteredLines.map((line) => {
//     return {
//       POLineId: line.POLineId,
//       LineNumber: line.LineNumber, 
//       LineType:  "Goods", 
//       Item: line.Item , 
//       Category: "Goods", 
//       Description: line.Description || "Peripherals_Type_Docking Stations",
//       Quantity: line.Quantity,
//       Price: line.Price,
//       UOM: line.UOM 
//     };
    
//   });


 const lines = LineADP.map((line) => {
	 const attachment = lineAttachments.find(att => att.LineNumber === line.LineNumber);
   const fileUrl = attachment && attachment.fileURL ? attachment.fileURL : null;
   console.log(fileUrl);
        if (line.POLineId) {
            if (line.CancelFlag === true) {
                return {
                    POLineId: line.POLineId,
                    CancelFlag: true,
                    CancelReason: "cancel line",
                    CancelUnfulfilledDemandFlag: "false"
                };
            } else if(!line.CancelFlag === true){
                return {
                    POLineId: line.POLineId,
                    LineNumber: line.LineNumber,
                    LineType: "Goods",
                    Item: line.Item,
                    Category: "Goods",
                    Description: line.Description || "Peripherals_Type_Docking Stations",
                    Quantity: line.Quantity,
                    Price: line.Price,
                    UOM: line.UOM,   
						"DFF": [
                {
                  "__FLEX_Context" : data.DocumentStyle,
                  "__FLEX_Context_DisplayValue" : data.DocumentStyle,
                  "attachment" : fileUrl

                }
            ]         
                };
            }
        }
    })

  // full payload structure
  return {

    ProcurementBUId: data.ProcurementBUId ,
    RequisitioningBUId: data.RequisitioningBUId ,
    BuyerId: data.BuyerId ,
    Supplier: data.Supplier ,
    Currency: data.Currency || "USD",
    DocumentStyleId : data.DocumentStyleId,
    SupplierSiteId: data.SupplierSiteId ,
    BillToLocation: data.BillToLocation ,
    DefaultShipToLocation: data.ShipToLocationCode ,
    RequiredAcknowledgment: data.RequiredAcknowledgment || "None",
    Description: data.Description || null,
    SupplierCommunicationMethod: data.SupplierCommunicationMethodCode ,
    SupplierEmailAddress: data.SupplierEmailAddress ,
    //SupplierContactId : data.SupplierContactId,
    ChangeOrderDescription : "Demo Change Order",
    ChangeOrderInitiatingParty : "BUYER" ,
    BuyerManagedTransportFlag: data.BuyerManagedTransportFlag || false,
    PayOnReceiptFlag: data.PayOnReceiptFlag || false,
    PaymentTerms: data.PaymentTerms ,
    ShippingMethod: data.ShippingMethod || "",
    FreightTermsCode: data.FreightTermsCode || null,
    FOBCode: data.FOBCode || null,
    NoteToReceiver: headerFileURL ? data.NoteToReceiver+" "+headerFileURL : data.NoteToReceiver || "",
    NoteToSupplier: data.NoteToSupplier || "",
    lines: lines // Dynamically created lines based on LineADP
  };
};







PageModule.prototype.createchangeOrderPayload = function (data, LineADP) {
  console.log("LineADP data:", JSON.stringify(LineADP));

//  const filteredLines = LineADP.filter(line => line.POLineId);
//   const lines = filteredLines.map((line) => {
//     return {
//       POLineId: line.POLineId,
//       LineNumber: line.LineNumber, 
//       LineType:  "Goods", 
//       Item: line.Item , 
//       Category: "Goods", 
//       Description: line.Description || "Peripherals_Type_Docking Stations",
//       Quantity: line.Quantity,
//       Price: line.Price,
//       UOM: line.UOM 
//     };
    
//   });


 const lines = LineADP.map((line) => {
        if (line.POLineId) {
            if (line.CancelFlag === true) {
                return {
                    POLineId: line.POLineId,
                    CancelFlag: true,
                    CancelReason: "cancel line",
                    CancelUnfulfilledDemandFlag: "false"
                };
            } else if(!line.CancelFlag === true){
                return {
                    POLineId: line.POLineId,
                    LineNumber: line.LineNumber,
                    LineType: "Goods",
                    Item: line.Item,
                    Category: "Goods",
                    Description: line.Description || "Peripherals_Type_Docking Stations",
                    Quantity: line.Quantity,
                    Price: line.Price,
                    UOM: line.UOM
                };
            }
        }
    })

  // full payload structure
  return {

    ProcurementBUId: data.ProcurementBUId ,
    RequisitioningBUId: data.RequisitioningBUId ,
    BuyerId: data.BuyerId ,
    Supplier: data.Supplier ,
    Currency: data.Currency || "USD",
    DocumentStyleId : data.DocumentStyleId,
    SupplierSiteId: data.SupplierSiteId ,
    BillToLocation: data.BillToLocation ,
    DefaultShipToLocation: data.ShipToLocationCode ,
    RequiredAcknowledgment: data.RequiredAcknowledgment || "None",
    Description: data.Description || null,
    SupplierCommunicationMethod: data.SupplierCommunicationMethodCode ,
    SupplierEmailAddress: data.SupplierEmailAddress ,
    //SupplierContactId : data.SupplierContactId,
    ChangeOrderDescription : "Demo Change Order",
    ChangeOrderInitiatingParty : "BUYER" ,
    BuyerManagedTransportFlag: data.BuyerManagedTransportFlag || false,
    PayOnReceiptFlag: data.PayOnReceiptFlag || false,
    PaymentTerms: data.PaymentTerms ,
    ShippingMethod: data.ShippingMethod || "",
    FreightTermsCode: data.FreightTermsCode || null,
    FOBCode: data.FOBCode || null,
    NoteToReceiver: data.NoteToReceiver || "",
    NoteToSupplier: data.NoteToSupplier || "",
    lines: lines // Dynamically created lines based on LineADP
  };
};

PageModule.prototype.createlinePayload = function (data, LineADP, lineAttachments) {
  console.log("LineADP data:", JSON.stringify(LineADP));

  const filteredLines = LineADP.filter(line => !line.POLineId);

  const lines = filteredLines.map((line) => {
    //new things
    const attachment = lineAttachments.find(att => att.LineNumber === line.LineNumber);
   const fileUrl = attachment && attachment.fileURL ? attachment.fileURL : null;
    return {
      LineNumber: line.LineNumber,
      LineType: "Goods",
      Item: line.Item,
      Category: "Goods",
      Description: line.Description || "Peripherals_Type_Docking Stations",
      Quantity: line.Quantity,
      Price: line.Price,
      UOM: line.UOM,
      	"DFF": [
                {
                  "__FLEX_Context" : data.DocumentStyle,
                  "__FLEX_Context_DisplayValue" : data.DocumentStyle,
                  "attachment" : fileUrl

                }
            ],
      schedules: [
        {
          ScheduleNumber: line.LineNumber,
          Quantity: line.Quantity,
          ShipToLocation: data.ShipToLocationCode,
          ShipToOrganizationCode: line.OrganizationCode,
          ReceiptCloseTolerancePercent: 0,
          InvoiceMatchOptionCode: "P",
          RequestedDeliveryDate: line.RequestedDeliveryDate,
          PromisedDeliveryDate: line.PromisedDeliveryDate,
          InvoiceCloseTolerancePercent: 0,
          InspectionRequiredFlag: true,
          ReceiptRequiredFlag: false,
          ReceiptRoutingId: 3,
          distributions: [
            {
              DistributionNumber: line.LineNumber,
              DeliverToLocation: data.ShipToLocationCode,
              Quantity: line.Quantity,
            }
          ]
        }
      ]
    };
  });

  return {
    lines: lines 
  };
};


// PageModule.prototype.createlinePayload = function (data, LineADP) {
//   console.log("LineADP data:", JSON.stringify(LineADP));

 
//   const lines = LineADP.map((line) => {
//     if(!line.POLineId){
//     return {
 
//       LineNumber: line.LineNumber, 
//       LineType:  "Goods", 
//       Item: line.Item , 
//       Category: "Goods", 
//       Description: line.Description || "Peripherals_Type_Docking Stations",
//       Quantity: line.Quantity,
//       Price: line.Price,
//       UOM: line.UOM , 
//       schedules: [
//         {
//           ScheduleNumber: line.LineNumber, 
//           Quantity: line.Quantity, 
//           ShipToLocation: data.ShipToLocationCode , 
//           ShipToOrganizationCode: line.OrganizationCode, 
//           ReceiptCloseTolerancePercent: 0, 
//           InvoiceMatchOptionCode: "P", 
//           RequestedDeliveryDate: line.RequestedDeliveryDate,
//           PromisedDeliveryDate: line.PromisedDeliveryDate,
//          // EarlyReceiptToleranceDays: 0,  
//           InvoiceCloseTolerancePercent: 0,  
//          // LateReceiptToleranceDays: 0,  
//          // AccrueAtReceiptFlag: true,  
//           InspectionRequiredFlag: true,  
//           ReceiptRequiredFlag: false,  
//           ReceiptRoutingId: 3,
//           //DestinationTypeCode: "INVENTORY",  
//           //Carrier: null,  
//          // RequestedDeliveryDate: "",  
//           distributions: [
//             {
//               DistributionNumber: line.LineNumber, 
//               DeliverToLocation: data.ShipToLocationCode, 
//               Quantity: line.Quantity, 
//             }
//           ]
//         }
//       ]
//     };
//   }
//   });

//   // full payload structure
//   return {

//     lines: lines // Dynamically created lines based on LineADP
//   };
// };

     PageModule.prototype.isSameReviewer = function (linesData) {
      let returnVal = 'Y';
      let from_reviewer = null;
      let to_reviewer = null;
      linesData.forEach(element => {
        if(element.from_reviewer !== element.to_reviewer){
           returnVal = 'N';
        }
        if(from_reviewer && element.from_reviewer !== from_reviewer){
           returnVal = 'FROM';
        }
        if(to_reviewer && element.from_reviewer !== to_reviewer){
           returnVal = 'TO';
        }
        from_reviewer = element.from_reviewer ;
        to_reviewer = element.to_reviewer ;
      });
      return returnVal;
    };

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
PageModule.prototype.cancelPOLine= function(data) {
//   return  {
// //   "ChangeOrderDescription": "Change order",
// //   "ChangeOrderInitiatingParty":"BUYER",
//   "lines" : [
//   {
//     "POLineId":data? data: '',
//     "CancelFlag": true,
//     "CancelReason": "cancel line",
//     "CancelUnfulfilledDemandFlag": "false"
//   }
//   ]
// }

 return [
        {
            "POLineId": data ? data : '',
            "CancelFlag": true,
            "CancelReason": "cancel line",
            "CancelUnfulfilledDemandFlag": "false",
            "LineNumber": '',
            "LineType": ''
              // Item: line.Item,
              //       Category: "Goods",
              //       Description: line.Description || "Peripherals_Type_Docking Stations",
              //       Quantity: line.Quantity,
              //       Price: line.Price,
              //       UOM: line.UOM
            
        }
    ];
};




  return PageModule;
});