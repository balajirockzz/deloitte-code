define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CollectionContainerSpExportChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

 if (!$flow.variables.searchFilter.request_id && !$flow.variables.searchFilter.buyer && !$flow.variables.searchFilter.status && (!$flow.variables.searchFilter.toDate && !$flow.variables.searchFilter.fromDate)) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Select Any of the Values in the Advance Filter to Export the Purchase Order Data',
          displayMode: 'persist',
          type: 'warning',
        });
        
      }
        else{



                let reportPath = '/Custom/GBL_Custom/Extension/STP/Procurement/STP_PROC_EXT_005_External_Buyer_PO_ExportUtility_Report.xdo';
                let bpa_number = $flow.variables.searchFilter.request_id ? $flow.variables.searchFilter.request_id : '';
                let from_date = $flow.variables.searchFilter.fromDate ? $flow.variables.searchFilter.fromDate : '';
                let to_date = $flow.variables.searchFilter.toDate ? $flow.variables.searchFilter.toDate : '';
                let buyer = $flow.variables.searchFilter.buyer ? $flow.variables.searchFilter.buyer : '';
                let status = $flow.variables.searchFilter.status ? $flow.variables.searchFilter.status : '';
                let exportArray =[];


            const results = await Promise.all([
        async () => {
          const bIPReportPayload = await $application.functions.getBIPReportPayloadExportBPAUtility(reportPath, bpa_number,from_date,to_date,buyer,status);

          const BIPReportResult = await Actions.callRest(context, {
            endpoint: 'BIPReport_conn/postExternalReportWSSService',
            body: bIPReportPayload,
          });

          if (BIPReportResult.ok) {
               exportArray = await $functions.convertbipresponseintoarray(BIPReportResult.body);     
               $flow.variables.actionApprovalADP.data = exportArray;   
               let buyerid = $application.user.userId;  

              await $functions.downloadExport(exportArray, buyerid);
                


                
           }
        },
      ].map(sequence => sequence()))
        }    }
  }

  return CollectionContainerSpExportChain;
});
