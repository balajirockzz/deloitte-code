define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class searchActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await $application.functions.openSpinnerDialog();

      $page.variables.filterObject = $flow.variables.searchFilter;
      $page.variables.qParameterForBPO='';

      let filterdate='';
      if($flow.variables.searchFilter.fromDate  &&  $flow.variables.searchFilter.toDate){
        filterdate = 'CreationDate  >='+  "'"+$flow.variables.searchFilter.fromDate+"'" +'and CreationDate <=' +"'"+$flow.variables.searchFilter.toDate+"'";

      }
      else{
        filterdate='';
      }

      let sText ='';
  

      if($variables.filterObject.text){
          sText = 'LIKE' + "'%"+$variables.filterObject.text.toUpperCase()+"%'";
      }
      else{
        sText = 'LIKE' +"'%%'";

      }
 
      if($flow.variables.searchFilter.request_id){
        if($flow.variables.searchFilter.status){
          if($flow.variables.searchFilter.buyer){
                      $page.variables.qParameterForBPO = 'OrderNumber=' +"'"+ $flow.variables.searchFilter.request_id+"'" +' and StatusCode='+"'"+$flow.variables.searchFilter.status+"'" + ' and BuyerId='+"'"+$flow.variables.searchFilter.buyer +"'"+filterdate;
            
          }
          else {
                      $page.variables.qParameterForBPO = 'OrderNumber=' +"'"+ $flow.variables.searchFilter.request_id+"'" +' and StatusCode='+"'"+$flow.variables.searchFilter.status+"'"+filterdate ;

          }

        }
        else{
                                $page.variables.qParameterForBPO= 'OrderNumber=' +"'"+ $flow.variables.searchFilter.request_id+"'"+filterdate ;

        }
      
      
      
      
    
      }
      else if ($flow.variables.searchFilter.status){
          if($flow.variables.searchFilter.buyer){
                              $page.variables.qParameterForBPO = 'StatusCode='+"'"+$flow.variables.searchFilter.status+"'" + ' and BuyerId='+"'"+$flow.variables.searchFilter.buyer +"'"+filterdate;
          }
          else {
                              $page.variables.qParameterForBPO ='StatusCode='+"'"+$flow.variables.searchFilter.status+"'"+filterdate;

      }
        
      }
      else if ($flow.variables.searchFilter.buyer){
                                      $page.variables.qParameterForBPO = 'BuyerId='+"'"+$flow.variables.searchFilter.buyer +"'"+filterdate;

      }
      else if ( $flow.variables.searchFilter.fromDate && $flow.variables.searchFilter.toDate){
                               $page.variables.qParameterForBPO = filterdate;


      }
      else{

  

    
      
      }
      
                             $page.variables.qParameterForBPO = ($page.variables.qParameterForBPO ? $page.variables.qParameterForBPO  +" and ":'')  +' ((UPPER(Buyer)'+sText+ ') or (UPPER(ProcurementBU)' +sText+') or (UPPER(OrderNumber) '+sText+') or (UPPER(Status)'+sText+ ') or (UPPER(Supplier)'+sText+'))';



        $page.variables.showFilter = false;
      
     

      await $application.functions.closeSpinnerDialog();
    }
  }

  

  return searchActionChain;
});
