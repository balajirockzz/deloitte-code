define([], () => {
  'use strict';

  class PageModule {

                  convertbipresponseintoarray(payload){


              function parseCSV(str) {
    const rows = [];
    let row = [];
    let value = '';
    let inQuotes = false;

    for (let i = 0; i < str.length; i++) {
        const char = str[i];
        const nextChar = str[i + 1];

        if (char === '"' && inQuotes && nextChar === '"') {
            value += '"';
            i++;
        } else if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            row.push(value);
            value = '';
        } else if (char === '\n' && !inQuotes) {
            row.push(value);
            rows.push(row);
            row = [];
            value = '';
        } else {
            value += char;
        }
    }

    if (value) {
        row.push(value);
    }
    if (row.length > 0) {
        rows.push(row);
    }

    return rows;
}

  const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(payload, "text/xml");
    const base64reportbyte = xmlDoc.querySelector("reportBytes").textContent;
    const base64decode = atob(base64reportbyte);

    // Parse the CSV data using the custom parser
    const data = parseCSV(base64decode);



    const titles = data[0];
    const jsonArray = data.slice(1).map(line => {
        return titles.reduce((obj, title, index) => {
            obj[title] = line[index];
            return obj;
        }, {});
    });

    // Call the downloadCSV function with jsonArray and headers

    return jsonArray;



              
            }



           downloadExport(arrayData,buyer) {



                    const headers = [
    "P_ORDER_STATUS", "P_END_DATE", "P_BUYER", "P_START_DATE", "P_PO_NUMBER", "CREATED_BY", 
    "SOLD_TO_LEGAL_ENTITY", "PROCUREMENT_BU", "REQUISITIONING_BU", "LINE_NUM", "ITEM_DESCRIPTION", 
    "ORDER_QTY", "UOM_CODE", "UNIT_PRICE", "LINE_AMOUNT", "TOTAL_PO_AMOUNT", "LINE_STATUS", 
    "SUPPLIER_NUMBER", "SUPPLIER", "SUPPLIER_SITE", "ORGANIZATION_CODE", "ORGANIZATION_NAME", 
    "DESTINATION_TYPE", "PO_NUMBER", "REVISION", "ORDER_STATUS", "PO_CURRENCY", "ORDER_CREATION_DATE", 
    "SUPPLIER_CONTACT", "LINE_TYPE", "BILL_TO", "DOCUMENT_STYLE", "PO_HEADER_BUYER", "LINE_BUYER"
];

    const filename = "POExport_"+Date.now()+"_"+buyer;

    const headerString = headers.join(",");

     //Convert JSON array to CSV string with proper quoting
    const csvContent = arrayData.map(row => 
        headers.map(header => {
            const value = row[header] || "";
            return value.includes(",") ? `"${value}"` : value;
        }).join(",")
    ).join("\n");

    // Combine headers and data
    const fullCSVContent = `${headerString}\n${csvContent}`;

    // Create a Blob from the CSV string
    const blob = new Blob([fullCSVContent], { type: 'text/csv;charset=utf-8;' });

    // Create a link element
    const link = document.createElement("a");

    // Create a URL for the Blob and set it as the href attribute
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);

    // Set the download attribute with the filename
    link.setAttribute("download", filename);

    // Append the link to the body
    document.body.appendChild(link);

    // Programmatically click the link to trigger the download
    link.click();

    // Remove the link from the document
    document.body.removeChild(link);

}



  }
  
  return PageModule;
});
