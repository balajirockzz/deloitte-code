/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spSubmitChain extends ActionChain {

    /**
     * Notify primary action is triggered
     * @param {Object} context
     */
    async run(context) {
      const { $variables, $application } = context;

      await $application.functions.openSpinnerDialog();

      let requestBody ={
        "username": $application.user.username,
        "items":[]
      };

     console.log($variables.selectedPoStyle );   
       console.log($variables.selectedBpoStyle );
       
       $variables.selectedPoStyle.forEach(val => { 
        $application.variables.poDocumentStyleADP.data.forEach(item => { 
          if(item.StyleId === val){
            requestBody.items.push(item);
          }
        });        
       });

        $variables.selectedBpoStyle.forEach(val => { 
        $application.variables.bpaDocumentStyleADP.data.forEach(item => { 
          if(item.StyleId === val){
            requestBody.items.push(item);
          }
        });        
       });



      const response = await Actions.callRest(context, {
        endpoint: 'ords_conn/postDocumentStyle',
        body: requestBody,
      });

      if (!response.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Rest API Error',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          type: 'confirmation',
          displayMode: 'transient',
          summary: 'Saved Successfully',
        });
      }

      await $application.functions.closeSpinnerDialog();
    }
  }

  return spSubmitChain;
});
