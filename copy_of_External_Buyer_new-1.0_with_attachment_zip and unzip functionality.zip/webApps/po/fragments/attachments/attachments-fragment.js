define([], () => {
  'use strict';

  class FragmentModule {
    fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = error => reject(error);
    });
}

// zipPickedFileseq(context) {
//   const files = context.$page.variables.filePicker1.files;
  
//   if (!files || files.length === 0) {
//     console.warn("No files selected.");
//     return;
//   }

//   const zip = new JSZip();

//   const fileReadPromises = [];

//   for (let i = 0; i < files.length; i++) {
//     const file = files[i];

//     const promise = new Promise((resolve, reject) => {
//       const reader = new FileReader();

//       reader.onload = function (e) {
//         zip.file(file.name, e.target.result);
//         resolve();
//       };

//       reader.onerror = function (e) {
//         reject(e);
//       };

//       reader.readAsArrayBuffer(file); // read file as binary data
//     });

//     fileReadPromises.push(promise);
//   }

//   Promise.all(fileReadPromises).then(() => {
//     zip.generateAsync({ type: "blob" }).then(function (zipBlob) {
//       // Trigger download
//       const downloadLink = document.createElement("a");
//       downloadLink.href = URL.createObjectURL(zipBlob);
//       downloadLink.download = "zipped_files.zip";
//       document.body.appendChild(downloadLink);
//       downloadLink.click();
//       document.body.removeChild(downloadLink);
//     });
//   }).catch((error) => {
//     console.error("Error zipping files:", error);
//   });
// };


  };

  
//new javascript
//  FragmentModule.prototype.zipnewnameFiles = async function (files) {
//     const zip = new JSZip();
//     const currentDateTime = new Date().toISOString().replace(/[:.]/g, '-');
//     const zipFileName = `archive-${currentDateTime}.zip`;
 
//     // Add files to the zip
//     for (let file of files) {
//       const fileData = await this.context.getFileData(file); // Assuming getFileData is a method to read file data
//       zip.file(file.name, fileData);
//     }
 
//     // Generate the zip file
//     const zipContent = await zip.generateAsync({ type: 'blob' });
 
//     // Save the zip file
//     await this.context.saveFile(zipFileName, zipContent); // Assuming saveFile is a method to save the file
 
//     console.log(`Zip file created: ${zipFileName}`);
//     return zipFileName;   
//    };


//old code by meet
// FragmentModule.prototype.ziphupFiles = async function (files) {
//   if (!files || files.length === 0) {
//     console.error("No files selected.");
//     return;
//   }

//   const zip = new JSZip();
//   const currentDateTime = new Date().toISOString().replace(/[:.]/g, '-');
//   const zipFileName = `archive-${currentDateTime}.zip`;

//   // Helper function to read file as ArrayBuffer
//   const readFile = (file) => {
//     return new Promise((resolve, reject) => {
//       const reader = new FileReader();
//       reader.onload = () => resolve(reader.result); // Fixed this line
//       reader.onerror = reject;
//       reader.readAsArrayBuffer(file);
//     });
//   };

//   try {
//     for (const file of files) {
//       const content = await readFile(file);
//       zip.file(file.name, content);
//     }

//     const zipBlob = await zip.generateAsync({ type: 'blob' });

//     // Trigger download
//     const a = document.createElement('a');
//     a.href = URL.createObjectURL(zipBlob);
//     a.download = zipFileName;
//     document.body.appendChild(a);
//     a.click();
//     document.body.removeChild(a);

//     console.log(`Zip file created and downloaded: ${zipFileName}`);
//     return zipFileName;
//   } catch (error) {
//     console.error("Error zipping files:", error);
//   }
// };

  return FragmentModule;
});

