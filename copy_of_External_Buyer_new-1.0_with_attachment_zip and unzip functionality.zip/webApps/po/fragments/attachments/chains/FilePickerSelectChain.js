define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {
    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      // Allowed file types
      const allowedFileTypes = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
'application/msword',
  'image/png',
  'image/jpeg',
  'text/csv',
  'audio/mpeg',
  'audio/wav',
  'audio/ogg',
  'video/mp4',
  'video/webm',
  'video/ogg',
];

      if (files && files.length > 0) {
        let validFiles = [];
        let invalidFiles = [];

        for (let selectedFile of files) {
          if (selectedFile.size > 10000000) {
            invalidFiles.push({
              file: selectedFile,
              error: 'File size is larger than 10MB!'
            });
            continue;
          }

          if (!allowedFileTypes.includes(selectedFile.type)) {
            invalidFiles.push({
              file: selectedFile,
              error: 'Invalid file format! Please upload a valid file.'
            });
            continue;
          }

          validFiles.push(selectedFile);
          $variables.filevarname=selectedFile.name;
          // $variables.storeUploadedDocVar = selectedFile;
          // $variables.attachmentPost.DOCUMENT_FILE = selectedFile;
          // $variables.attachmentPost.DOCUMENT_NAME = selectedFile.name;
          // $variables.attachmentPost.DOCUMENT_TYPE = selectedFile.type;

          await Actions.fireNotificationEvent(context, {
            summary: `${selectedFile.name} uploaded successfully.`,
            severity: 'confirmation',
          });
        }

        if (invalidFiles.length > 0) {
          for (let invalid of invalidFiles) {
            await Actions.fireNotificationEvent(context, {
              summary: invalid.error,
              severity: 'error',
            });
          }
        }

        if (validFiles.length === 0) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No valid files were uploaded!',
            severity: 'error',
          });
          return;
        }

        // Create ZIP and download
         await new Promise((resolve, reject) => {
          console.log("Inside Zip Function");

          require([
            'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.6.0/jszip.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.js'
          ], (JSZip, FileSaver) => {

            // Define and call async function separately
            (async function zipAndSave() {
              try {
                const zip = new JSZip();
                console.log("CDN Loaded");

                // Step 1: Load old zip if it exists
                if ($variables.generatedZipBlob) {
                  console.log("Previous Zip Exists.");
                  const oldZip = await JSZip.loadAsync($variables.generatedZipBlob);
                  const oldFiles = Object.keys(oldZip.files);

                  for (let name of oldFiles) {
                    const fileContent = await oldZip.file(name).async('blob');
                    zip.file(name, fileContent);
                  }
                }

                console.log("Adding New Files.");
                validFiles.forEach(file => {
                  zip.file(file.name, file);
                });
                console.log("Added New Files.");

                // Step 3: Generate zip
                console.log("Zipping Files...");
                const blob = await zip.generateAsync({ type: 'blob' });
                $variables.generatedZipBlob = blob;
                console.log("Updated ZIP Blob: ", blob);

                // saveAs(blob, 'combined_files.zip');
                resolve();
              } catch (error) {
                console.error('Zip creation failed:', error);
                reject(error);
              }
            }());
          });
        });

        const fileToBase64 = await $functions.fileToBase64($variables.generatedZipBlob);

        // ---- TODO: Add your code here ---- //
        console.log('filetobase64bit',fileToBase64);

        $variables.fileContent = fileToBase64;

        $variables.fileName = $variables.filevarname.replace(/\.[^/.]+$/, '') + '.zip';

        await Actions.fireNotificationEvent(context, {
          summary: $variables.fileName,
          message: $variables.fileType,
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'No file selected!',
          severity: 'error',
        });
      }
    }
  }

  return FilePickerSelectChain;
});
