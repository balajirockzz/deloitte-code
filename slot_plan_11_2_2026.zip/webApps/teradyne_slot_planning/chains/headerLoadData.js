define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class headerLoadData extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.header_id
     */
    async run(context, { header_id }) {
      const { $application, $constants, $variables } = context;


      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetheaderdetails',
        uriParams: {
          'p_slot_number': header_id,
        },
      });

      $variables.headerVar.customer = response.body.items[0].customer;
      $variables.headerVar.pd_qtr = response.body.items[0].pd_qtr;
      $variables.headerVar.platform = response.body.items[0].platform;
      $variables.headerVar.slot_id = response.body.items[0].slot_id;
      $variables.headerVar.slot_number = response.body.items[0].slot_number;
      $variables.headerVar.slot_status = response.body.items[0].slot_status;
      $variables.headerVar.slot_type = response.body.items[0].slot_type;
      $variables.headerVar.system = response.body.items[0].system;
      $variables.headerVar.mrp_qtr = response.body.items[0].mrp_qtr;
      $variables.headerVar.planning_organization = response.body.items[0].planning_organization;
      $variables.headerVar.manufacture = response.body.items[0].manufacture;
      $variables.headerVar.manufacture_site = response.body.items[0].manufacture_site;
      $variables.headerVar.schedule_date = response.body.items[0].schedule_date;
      $variables.headerVar.promised_date = response.body.items[0].promised_date;
      $variables.headerVar.config_number = response.body.items[0].config_number;
      $variables.headerVar.operation_comments = response.body.items[0].operation_comments;
      $variables.headerVar.marketing_comments = response.body.items[0].marketing_comments;
    }
  }

  return headerLoadData;
});
