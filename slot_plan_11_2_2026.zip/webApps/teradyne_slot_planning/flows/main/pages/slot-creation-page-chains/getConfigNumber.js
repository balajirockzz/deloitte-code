define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getConfigNumber extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetConfigDetails',
        uriParams: {
          'p_slot_type': $variables.creationSlotVariables.slotType,
          'p_platform': $variables.creationSlotVariables.platform,
          'p_system': $variables.creationSlotVariables.system,
        },
      });

      if (response.body.items.length === 0) {
        await Actions.fireNotificationEvent(context, {
          type: 'error',
          summary: 'No Config exists for this combination!',
          displayMode: 'transient',
        });
        
      } else {

        $variables.configNumberADP.data = response.body.items;
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });
    }
  }

  return getConfigNumber;
});
