define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class platformSelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {any} params.data
     * @param {any} params.metadata
     * @param {any} params.valueItem
     */
    async run(context, { event, previousValue, value, updatedFrom, key, data, metadata, valueItem }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      if ($variables.isSaveSlotTriggered !== true) {
        const loadingDialogOpen = await Actions.callComponentMethod(context, {
          selector: '#loadingDialog',
          method: 'open',
        });

        const payload = await $functions.payload('/Custom/Teradyne/Extension/SLOT_PLANNING/Report/TER_GET_ITEM_NUM_SP_RPT.xdo', 'p_category_name', key, 'p_item_type', 'ATOP');

        const response = await Actions.callRest(context, {
          endpoint: 'fusionService/runBIPReport',
          body: payload,
        });

        const readBINullData = await $functions.readBINullData(response.body);

        if (readBINullData === 'DQoNCg==') {
          await Actions.fireNotificationEvent(context, {
            type: 'warning',
            summary: 'No System Exists in Fusion against this Platform!',
            displayMode: 'transient',
          });

          await Actions.resetVariables(context, {
            variables: [
              '$variables.creationSlotVariables.system',
            ],
          });
        } else {

          const readBIPreportData = await $functions.readBIPreportData(response.body);

          $variables.systemADP.data = readBIPreportData;
        }

        if (
          $variables.creationSlotVariables?.system?.[0] &&
          key?.[0] &&
          $variables.creationSlotVariables?.slotType?.[0]
        ) {
          await Actions.callChain(context, {
            chain: 'getConfigNumber',
          });
        }

        const loadingDialogClose = await Actions.callComponentMethod(context, {
          selector: '#loadingDialog',
          method: 'close',
        });
      }
    }
  }

  return platformSelectValueItemChangeChain;
});
