define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;


      await Actions.resetVariables(context, {
        variables: [
    '$variables.creationSlotVariables',
  ],
      });

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      const response = await Actions.callRest(context, {
        endpoint: 'fusionService/getDemandLookup',
        uriParams: {
          lookupType: 'ORA_DOO_DEMAND_CLASS',
        },
      });

      const responseSlotTypelov = await Actions.callRest(context, {
        endpoint: 'SlotPlanningModule/getGetslottypelov',
      });

      const responseSuppliers = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetSuppliers',
      });

      $variables.demandClassADP.data = response.body.items;
      $variables.slotTypeADP.data = responseSlotTypelov.body.items;
      $variables.suppliersADP.data = responseSuppliers.body.items;

      const payload = await $functions.payload( '/Custom/Teradyne/Extension/SLOT_PLANNING/Report/TER_GET_PLATFORM_SP_RPT.xdo',undefined, undefined, undefined, undefined);

      const responsePlatformlov = await Actions.callRest(context, {
        endpoint: 'fusionService/runBIPReport',
        body: payload,
      });

      const readBINullData = await $functions.readBINullData(responsePlatformlov.body);

      if (readBINullData === 'DQoNCg==') {
        await Actions.fireNotificationEvent(context, {
          type: 'error',
          summary: 'No Platform Exists in Fusion!',
          displayMode: 'transient',
        });
      } else {

        const readBIPreportData = await $functions.readBIPreportData(responsePlatformlov.body);

        $variables.platformADP.data = readBIPreportData;
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });
    }
  }

  return vbEnterListener;
});
