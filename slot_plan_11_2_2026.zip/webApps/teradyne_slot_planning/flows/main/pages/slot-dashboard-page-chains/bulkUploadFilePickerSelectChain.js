define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class bulkUploadFilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {object[]} params.files
     * @param {any} params.originalEvent
     */
    async run(context, { event, files, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.getCSVRecords',
  ],
      });

      const progressMsgOpen = await Actions.callComponentMethod(context, {
        selector: '#progressMsg',
        method: 'open',
      });

      const OICResponse = await Actions.callRest(context, {
        endpoint: 'integrationService/postValidateBulkUploadData',
        body: {
          files: files[0],
        },
      });


      if(String(OICResponse.body.Status).indexOf('Error') !== -1){
        await Actions.fireNotificationEvent(context, {
          summary: "{{OICResponse.body.Status}}",
          displayMode: 'transient',
          type: 'error',
        });

      } else if (OICResponse.ok === false){


        await Actions.fireNotificationEvent(context, {
          summary: 'OICResponse.body',
          displayMode: 'transient',
          type: 'error',
        });
      }
      else {
        const validRecordsResponse = await Actions.callRest(context, {
          endpoint: 'ordsService/getGetBulkUploadCSVRecords',
          uriParams: {
            'p_fileName': files[0].name,
            'p_status': 'VALID',
          },
        });

        if (validRecordsResponse.body.items.length !== 0) {
          const bulkuploadProcessPayloads = await $functions.bulkuploadProcessPayloads(validRecordsResponse.body.items, $application.user.fullName);

          const createSlotResponse = await Actions.callRest(context, {
            endpoint: 'ordsService/postPlanDetailsTableAction',
            body: bulkuploadProcessPayloads,
          });
        }

        const invalidRecordsResponse = await Actions.callRest(context, {
          endpoint: 'ordsService/getGetBulkUploadCSVRecords',
          uriParams: {
            'p_fileName': files[0].name,
            'p_status': 'INVALID',
          },
        });

        if (invalidRecordsResponse.body.items.length !== 0) {

          const progressMsgClose2 = await Actions.callComponentMethod(context, {
            selector: '#progressMsg',
            method: 'close',
          });

          $variables.getCSVRecords.data = invalidRecordsResponse.body.items;
          $variables.invalidFileName = 'Invalid_' + files[0].name.split('.')[0] + '_' + $functions.getDate(Date.now()) + '.csv';

          const bulkInvalidUploadDialogOpen = await Actions.callComponentMethod(context, {
            selector: '#bulkInvalidUploadDialog',
            method: 'open',
          });

          await Actions.fireNotificationEvent(context, {
            displayMode: 'transient',
            summary: 'Slot creation failed for some records!',
            message: 'Please review the validation results and retry.',
            type: 'error',
          });
        } else {
          await Actions.fireNotificationEvent(context, {
            type: 'confirmation',
            displayMode: 'transient',
            summary: 'Slots Successfully Created!',
          });
        }
      }

      const progressMsgClose = await Actions.callComponentMethod(context, {
        selector: '#progressMsg',
        method: 'close',
      });
    }
  }

  return bulkUploadFilePickerSelectChain;
});
