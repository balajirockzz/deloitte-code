define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onClickFilterSearch extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.Filter_Obj',
    '$variables.Filter_Obj.customer_name',
    '$variables.Filter_Obj.period',
    '$variables.Filter_Obj.product_type',
    '$variables.Filter_Obj.slot_number',
    '$variables.Filter_Obj.slot_type',
    '$variables.Filter_Obj.status',
  ],
      });

      const searchfilterOpen = await Actions.callComponentMethod(context, {
        selector: '#searchfilter',
        method: 'open',
      });
    }
  }

  return onClickFilterSearch;
});
