define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onClickdeletebuttonpopup extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/postDeletetabledetails',
        uriParams: {
          'p_slot_number': $variables.deleteKeyVar,
        },
      });

      if (response.body.o_status === 'Failed') {
        await Actions.fireNotificationEvent(context, {
          summary: response.body.o_status,
          message: response.body.o_error_message,
          displayMode: 'persist',
          type: 'error',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: response.body.o_status,
          message: response.body.o_error_message,
          displayMode: 'transient',
          type: 'confirmation',
        });

        const deletepopupClose = await Actions.callComponentMethod(context, {
          selector: '#deletepopup',
          method: 'close',
        });

        await Actions.callChain(context, {
          chain: 'vbEnterListener',
        });
      }
    }
  }

  return onClickdeletebuttonpopup;
});
