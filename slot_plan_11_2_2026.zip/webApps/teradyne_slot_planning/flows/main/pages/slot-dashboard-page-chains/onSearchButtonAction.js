define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onSearchButtonAction extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      if ($variables.Search_obj.search_value == null) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Please Enter a Value in Search Field',
          displayMode: 'persist',
          type: 'error',
        });
      } else {
         const response = await Actions.callRest(context, {
           endpoint: 'ordsService/getGetsearchtable',
           uriParams: {
             'p_searchvalue': $variables.Search_obj.search_value,
           },
         });

        if (!response.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Error During Rest Action',
            displayMode: 'persist',
            type: 'error',
          });
        } else {

          $variables.Search_table_ADP.data = response.body.items;

          await Actions.resetVariables(context, {
            variables: [
    '$variables.exportADP',
    '$variables.exportADP.data',
  ],
          });

          const response2 = await Actions.callRest(context, {
            endpoint: 'ordsService/getGetexportsearchdetails',
            uriParams: {
              'p_searchvalue': $variables.Search_obj.search_value,
            },
          });

          if (!response2.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Error During Rest Action in Export Search',
              displayMode: 'persist',
              type: 'error',
            });
          } else {
            $variables.exportADP.data = response2.body.items;
          }
        }
      }

    }
  }

  return onSearchButtonAction;
});
