define([
  'knockout',
  'ojs/ojresponsiveknockoututils',
  'ojs/ojresponsiveutils',
  'ojs/ojpagingdataproviderview',
  'ojs/ojarraydataprovider',
  'ojs/ojanimation',
  'ojs/ojkeyset',
  'ojs/ojarraytreedataprovider',
  'ojs/ojconverter-datetime'
], function (
  ko,
  ResponsiveKnockoutUtils,
  ResponsiveUtils,
  PagingDataProviderView,
  ArrayDataProvider,
  AnimationUtils,
  keySet,
  ArrayTreeDataProvider,
  datetimeConverter
) {
  'use strict';

  let navigationMenu = [
    {
      id: "navigation",
      label: "Navigation",
      node: "parent",
      items: [
        {
          id: "slots",
          label: "Slots",
          icon: "calendar"
        },
        {
          id: "manageConfiguration",
          label: "Manage Configuration",
          icon: "settings",
        },
        {
          id: "changeRequests",
          label: "Change Requests",
          icon: "pull-request",
        }
      ],
    }
    // {
    //   id: "quickActions",
    //   label: "Quick Actions",
    //   node: "parent",
    //   items: [
    //     // {
    //     //   id: "newSlot",
    //     //   label: "New Slot",
    //     //   icon: "plus",
    //     // },
    //     {
    //       id: "bulkUpload",
    //       label: "Bulk Upload",
    //       icon: "upload"
    //     },
    //     {
    //       id: "exportData",
    //       label: "Export Data",
    //       icon: "download"
    //     },
    //   ],
    // }
  ];

  class PageModule {
    constructor() {
      this.metadata = {
        navigationMenu: navigationMenu,
      };
      this.navlistExpanded = ko.observable(new keySet.KeySetImpl());
    }

    getMetadata() {
      return this.metadata;
    }

    getNavigationContent(metadata) {
      if (this.navigationContent === undefined) {
        this.navigationContent = ko.observable(
          new ArrayTreeDataProvider(
            this._getNavigationData(metadata.navigationMenu),
            {
              keyAttributes: "attr.id",
            }
          )
        );
      }
      return this.navigationContent;
    }

    _getNavigationData(menu) {
      let navData = [],
        self = this;

      for (let i = 0; i < menu.length; i++) {
        let menuItem = {};
        let origMenuItem = menu[i];
        if (typeof origMenuItem === "object") {
          menuItem.attr = {
            id: origMenuItem.id,
            name: origMenuItem.label,
            icon: origMenuItem.icon,
            badge: origMenuItem.badge,
            node: origMenuItem.node,
          };
        }
        if (origMenuItem.items && origMenuItem.items.length > 0)
          menuItem.children = this._getNavigationData(origMenuItem.items);
        navData.push(menuItem);
      }
      return navData;
    }

    itemSelectable(context) {
      return context.leaf;
    }

    bulkuploadProcessPayloads(payloadData, creatdBy) {
      // const slots = [].concat(payloadData);
      const finalPayload = [];
      // { "items": [] };

      for (let i = 0; i < payloadData.length; i++) {
        const slot = payloadData[i];

        const processedObj = {
          PD_QTR: slot.pd_qtr,
          PLATFORM: slot.platform,
          SYSTEM: slot.system,
          SLOT_TYPE: slot.slot_type,
          SLOT_STATUS: 'Open',
          DEMAND_CLASS: slot.demand_class,
          CONFIG_NUMBER: slot.config_number,
          SCHEDULE_DATE: slot.schedule_date,
          PROMISED_DATE: slot.promised_date,
          MRP_QTR: slot.mrp_qtr,
          SLOT_NUMBER: slot.slot_number,
          CREATED_BY: creatdBy,
          PLANNING_ORGANIZATION: slot.planning_organization,
          MANUFACTURE: slot.manufacture,
          MANUFACTURE_SITE: slot.manufacture_site,
          OPERATION_COMMENTS: slot.operation_comments,
          MARKETING_COMMENTS: slot.marketing_comments
        };

        if (processedObj.SLOT_NUMBER === undefined) processedObj.SLOT_NUMBER = null;

        finalPayload.push(processedObj);
      }

      return finalPayload;
    }

    getDate(param) {
      const dateConverter = new datetimeConverter.IntlDateTimeConverter({
        pattern: "yyyy-MM-dd"
      });
      return dateConverter.format(param);
    }

  }
  // search table data for the pagination
  PageModule.prototype.searchtable = function (array) {
    const data = new PagingDataProviderView(new ArrayDataProvider(
      array, {
      idAttribute: 'slot_id'
    }));
    return data;
  };

PageModule.prototype.getexportfilename = function() {
  const d = new Date();

    const year = d.getFullYear();
    const month = ('0' + (d.getMonth() + 1)).slice(-2);
    const day = ('0' + d.getDate()).slice(-2);

    return 'SlotPlanning' + '_' + year + '-' + month + '-' + day;
  };


  return PageModule;
});
