define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onClickSaveButton extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      if ($variables.methodVar === 'POST') {
        $variables.financeEditVariable.created_date = $application.functions.getSysdate();
        $variables.financeEditVariable.updated_date = $application.functions.getSysdate();

        $variables.financeEditVariable.created_by = $application.user.username;
        $variables.financeEditVariable.updated_by = $application.user.username;
      } else {
        $variables.financeEditVariable.updated_date = $application.functions.getSysdate();
        $variables.financeEditVariable.updated_by = $application.user.username;
      }

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/postPostFinanceDetails',
        uriParams: {
          'p_method': $variables.methodVar,
          'p_primarykey': $variables.PrimaryKeyVar,
        },
        body: $variables.financeEditVariable,
      });

      if (response.body.p_err_code === 'S') {
        await Actions.fireNotificationEvent(context, {
          summary: response.body.p_err_msg,
          displayMode: 'transient',
          type: 'info',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          displayMode: 'persist',
          type: 'error',
          summary: response.body.p_err_msg,
        });
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });
    }
  }

  return onClickSaveButton;
});
