define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;


      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      $variables.revenueRiskADP.data = $variables.revenueRiskVar;

      $variables.adjCommentVarADP.data = $variables.adjCommentVar;

      await Actions.callChain(context, {
        chain: 'application:headerLoadData',
        params: {
          'header_id': $application.variables.globalSlotNumber,
        },
      });

      $variables.financeEditVariable.platform = $application.variables.headerVar.platform;
      $variables.financeEditVariable.system = $application.variables.headerVar.system;
      $variables.financeEditVariable.slot_number = $application.variables.headerVar.slot_number;
      $variables.financeEditVariable.slot_status = $application.variables.headerVar.slot_status;
      $variables.financeEditVariable.slot_type = $application.variables.headerVar.slot_type;
      $variables.financeEditVariable.pd_qtr = $application.variables.headerVar.pd_qtr;
      $variables.financeEditVariable.customer = $application.variables.headerVar.customer;
      $variables.financeEditVariable.slot_id = $application.variables.headerVar.slot_id;

      const response2 = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetFinanceDetails',
        uriParams: {
          'p_slot_number': $application.variables.globalSlotNumber,
        },
      });

      if (response2.body.count === 0) {
        $variables.methodVar = 'POST';
        $variables.PrimaryKeyVar = '0';
      } else {
        $variables.methodVar = 'PUT';
        $variables.PrimaryKeyVar = $variables.financeEditVariable.slot_number;

        $variables.financeEditVariable.revenue_risk = response2.body.items[0].revenue_risk;
        $variables.financeEditVariable.system_count_adj = response2.body.items[0].system_count_adj;
        $variables.financeEditVariable.revenue_adj = response2.body.items[0].revenue_adj;
        $variables.financeEditVariable.cogs_adj = response2.body.items[0].cogs_adj;
        $variables.financeEditVariable.adjustment_comment = response2.body.items[0].adjustment_comment;
        $variables.financeEditVariable.finance_comments = response2.body.items[0].finance_comments;
        $variables.financeEditVariable.revenue_qtr = response2.body.items[0].revenue_qtr;
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });
    }
  }

  return vbEnterListener;
});
