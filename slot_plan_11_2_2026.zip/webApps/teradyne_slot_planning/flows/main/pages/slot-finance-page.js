define([
  'knockout',
  'ojs/ojresponsiveknockoututils',
  'ojs/ojresponsiveutils',
  'ojs/ojpagingdataproviderview',
  'ojs/ojarraydataprovider',
  'ojs/ojanimation',
  'ojs/ojkeyset',
  'ojs/ojarraytreedataprovider'
], function (
  ko,
  ResponsiveKnockoutUtils,
  ResponsiveUtils,
  PagingDataProviderView,
  ArrayDataProvider,
  AnimationUtils,
  keySet,
  ArrayTreeDataProvider
) {
  'use strict';

  class PageModule {
  }

      PageModule.prototype.getslotvalue = function (slotType) {
if(slotType === 'Non-Operational Slot'){
  return 0;
}
return 1;
  };


  return PageModule;
});