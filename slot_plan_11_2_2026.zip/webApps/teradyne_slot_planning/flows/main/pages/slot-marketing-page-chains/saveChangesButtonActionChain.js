define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveChangesButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getMarketingTableAction',
        uriParams: {
          'p_slot_number': $application.variables.globalSlotNumber,
        },
      });

      const newDate = await $application.functions.newDate();

      $variables.marketingSlotVariables.updatedDate = newDate;

      const processPayloads = await $functions.processPayloads($variables.marketingSlotVariables, $variables.slotTypeValue);

      if (response.body.items.length === 0) {
        const responsePostMarketing = await Actions.callRest(context, {
          endpoint: 'ordsService/postMarketingTableAction',
          uriParams: {
          'p_method': 'POST'
        },
          body: processPayloads,
        });

        if (responsePostMarketing.body.p_err_code === 'Success') {

          await Actions.fireNotificationEvent(context, {
            summary: 'Marketing Changes Saved Successfully!',
            displayMode: 'transient',
            type: 'confirmation',
          });
        } else {
          await Actions.fireNotificationEvent(context, {
            displayMode: 'persist',
            type: 'error',
            summary: 'Error While Saving Marketing Changes!',
            message: responsePostMarketing.body.p_err_msg,
          });
        }
      } else {

        const responsePutMarketing = await Actions.callRest(context, {
          endpoint: 'ordsService/postMarketingTableAction',
          uriParams: {
          'p_method': 'PUT',
        },
        body: processPayloads,
        });

        if (responsePutMarketing.body.p_err_code === 'Success') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Marketing Changes Saved Successfully!',
            displayMode: 'transient',
            type: 'confirmation',
          });
        } else {
          await Actions.fireNotificationEvent(context, {
            displayMode: 'persist',
            type: 'error',
            summary: 'Error While Saving Marketing Changes!',
            message: responsePutMarketing.body.p_err_msg,
          });
        }


      }


    }
  }

  return saveChangesButtonActionChain;
});
