define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class slotTypeSelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {any} params.data
     * @param {any} params.metadata
     * @param {any} params.valueItem
     */
    async run(context, { event, previousValue, value, updatedFrom, key, data, metadata, valueItem }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (previousValue.data.slot_type === "Revenue" && value.data.slot_type !== "Upside" || previousValue.data.slot_type === "Upside" && value.data.slot_type !== "Revenue") {
        await Actions.fireNotificationEvent(context, {
          summary: 'Slot Type is not selected properly!',
          displayMode: 'transient',
          type: 'error',
        });

        $variables.slotTypeValue[0] = previousValue.data.slot_type;
      }
    }
  }

  return slotTypeSelectValueItemChangeChain;
});
