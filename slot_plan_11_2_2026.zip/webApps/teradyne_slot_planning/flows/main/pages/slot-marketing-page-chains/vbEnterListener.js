define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      await Actions.callChain(context, {
        chain: 'application:headerLoadData',
        params: {
          'header_id': $application.variables.globalSlotNumber,
        },
      });

      const responseSlotTypelov = await Actions.callRest(context, {
        endpoint: 'SlotPlanningModule/getGetslottypelov',
      });

      $variables.slotTypeADP.data = responseSlotTypelov.body.items;


      $variables.marketingSlotVariables.configNumber = $application.variables.headerVar.config_number;
      $variables.marketingSlotVariables.createdBy = $application.user.fullName;
      $variables.marketingSlotVariables.customer = $application.variables.headerVar.customer;
      $variables.marketingSlotVariables.pdQtr = $application.variables.headerVar.pd_qtr;
      $variables.marketingSlotVariables.platform = $application.variables.headerVar.platform;
      $variables.marketingSlotVariables.promisedDate = $application.variables.headerVar.promised_date?.slice?.(0, 10);
      $variables.marketingSlotVariables.scheduledDate = $application.variables.headerVar.schedule_date?.slice?.(0, 10);
      $variables.marketingSlotVariables.slotNumber = $application.variables.headerVar.slot_number;
      $variables.marketingSlotVariables.slotStatus = $application.variables.headerVar.slot_status;
      $variables.marketingSlotVariables.system = $application.variables.headerVar.system;
      $variables.marketingSlotVariables.updatedBy = $application.user.fullName;
      $variables.marketingSlotVariables.marketingComments = $application.variables.headerVar.marketing_comments;

      const slotType = $application.variables.headerVar.slot_type;

      $variables.selectedSlotType = {
        key: $application.variables.headerVar.slot_type,
        data: { slot_type: slotType }
      };

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });

    }
  }

  return vbEnterListener;
});
