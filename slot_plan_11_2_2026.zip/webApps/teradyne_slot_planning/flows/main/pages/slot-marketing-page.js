define([], () => {
  'use strict';

  class PageModule {
    
    processPayloads(payloadData, slotTypeValue) {
      const slot = payloadData;
      // const finalPayload = {};
      // let processedObj = {};

      let processedObj = {
        configNumber: slot.configNumber,
        scheduledDate: slot.scheduledDate,
        marketingComments: slot.marketingComments,
        createdBy: slot.createdBy,
        updatedBy: slot.updatedBy,
        updatedDate: slot.updatedDate?.slice?.(0, 10),
        slotType: (slot?.slotType ?? slotTypeValue) ?? slotTypeValue,
        promisedDate: slot.promisedDate,
        slotNumber: slot.slotNumber
      };

      return processedObj;
    }

  }
  
  return PageModule;
});
