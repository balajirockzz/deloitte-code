define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class addPartialTableSelectedChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {object} params.previousValue
     * @param {object} params.value
     * @param {string} params.updatedFrom
     * @param {any[]} params.keys
     * @param {any} params.selected
     */
    async run(context, { event, previousValue, value, updatedFrom, keys, selected }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      let selectedRows = $variables.addPartialDialogSelectedRows;
      let isAllSelected = selectedRows.keys.all;
      let selecteddKeys = selectedRows.keys.keys;
      let uncheckedKeys = selectedRows.keys.deletedKeys;
      let csvValue;

      if (isAllSelected === true) {
        if (uncheckedKeys.size > 0) {
          const filterArrayDataProvider = await $functions.filterArrayDataProviderByDeletedCSV($variables.getAllConfigDetailsADP.data, Array.from(uncheckedKeys).join(','), 'part_num');
          csvValue = filterArrayDataProvider.data.map(item => item.part_num).join(',');
        } else {
          csvValue = $variables.getAllConfigDetailsADP.data.map(item => item.part_num).join(',');
        }
      } else {
        csvValue = Array.from(selectedRows.keys.keys).join(',');
      }

      if (!csvValue) {

        const response = await Actions.callRest(context, {
          endpoint: 'ordsService/getGetFilteredPartialDetails',
          uriParams: {
            'p_part_numbers': csvValue,
          },
        });

        $variables.selectedAddPartialDetailsADP.data = response.body.items;
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });


    }
  }

  return addPartialTableSelectedChangeChain;
});
