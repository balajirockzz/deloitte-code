define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class applyPartialDetailsButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      const chunkSize = 100;
      let currentIndex = 0;
      while (currentIndex < $variables.selectedAddPartialDetailsADP.data.length) {
        const chunk = $variables.selectedAddPartialDetailsADP.data.slice(currentIndex, currentIndex + chunkSize);
        $variables.addPartialDetailsADP.data.push(...chunk);
        // $page.variables.assignmentPopupArray.push(...chunk);
        currentIndex += chunkSize;
        setTimeout(() => { }, 0);
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });

    }
  }

  return applyPartialDetailsButtonActionChain;
});
