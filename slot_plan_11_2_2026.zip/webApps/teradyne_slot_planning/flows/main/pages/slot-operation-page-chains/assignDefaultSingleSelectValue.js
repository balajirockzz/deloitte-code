define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class assignDefaultSingleSelectValue extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const plannedOrg = $application.variables.headerVar.planning_organization;

      $variables.selectedPlannedOrg = {
        key: $application.variables.headerVar.planning_organization,
        data: { organizationName: plannedOrg }
      };

      const configNum = $application.variables.headerVar.config_number;
      
      $variables.selectedConfigNumber = {
        key: $application.variables.headerVar.config_number,
        data: { config_num: configNum }
      };
      
      const manufactureSite = $application.variables.headerVar.manufacture_site;
      
      $variables.selectedManufactureSite = {
        key: $application.variables.headerVar.manufacture_site,
        data: { vendorsitecode: manufactureSite }
      };

    }
  }

  return assignDefaultSingleSelectValue;
});
