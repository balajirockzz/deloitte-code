define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveChangesButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getOperationTableAction',
        uriParams: {
          'p_slot_number': $application.variables.globalSlotNumber,
        },
      });
      $variables.operationSlotVariables.createdBy = $application.user.fullName;
      $variables.operationSlotVariables.updatedBy = $application.user.fullName;
      $variables.operationSlotVariables.updatedDate = $application.functions.getSysdate();

      // if ($variables.operationSlotVariables.slotType === undefined || $variables.operationSlotVariables.slotType === null) {
      //   $variables.operationSlotVariables.slotType = $variables.slotTypeValue;
      // }
      // if ($variables.operationSlotVariables.configNumber === undefined || $variables.operationSlotVariables.configNumber === null) {
      //   $variables.operationSlotVariables.configNumber = $variables.configNumberValue;
      // }
      // if ($variables.operationSlotVariables.planningOrganization === undefined || $variables.operationSlotVariables.planningOrganization === null) {
      //   $variables.operationSlotVariables.planningOrganization = $variables.plannedOrgValue;
      // }
      // if ($variables.operationSlotVariables.manufacture === undefined || $variables.operationSlotVariables.manufacture === null) {
      //   $variables.operationSlotVariables.manufacture = $variables.manufactureValue;
      // }
      // if ($variables.operationSlotVariables.manufactureSite === undefined || $variables.operationSlotVariables.manufactureSite === null) {
      //   $variables.operationSlotVariables.manufactureSite = $variables.manufactureSiteValue;
      // }

      const processPayloads = await $functions.processPayloads($variables.operationSlotVariables, $variables.slotTypeValue, $variables.plannedOrgValue, $variables.configNumberValue, $variables.manufactureValue, $variables.manufactureSiteValue);

      if (response.body.items.length === 0) {
        const responsePostOperation = await Actions.callRest(context, {
          endpoint: 'ordsService/postOperationTableAction',
          uriParams: {
          'p_method': 'POST'
        },
          body: processPayloads,
        });

        if (responsePostOperation.body.p_err_code === 'Success') {

          await Actions.fireNotificationEvent(context, {
            summary: 'Operation Changes Saved Successfully!',
            displayMode: 'transient',
            type: 'confirmation',
          });
        } else {
          await Actions.fireNotificationEvent(context, {
            displayMode: 'transient',
            type: 'error',
            summary: 'Error While Saving Operation Changes!',
            message: responsePostOperation.body.p_err_msg,
          });
        }
      } else {

        const responsePutOperation = await Actions.callRest(context, {
          endpoint: 'ordsService/postOperationTableAction',
          uriParams: {
          'p_method': 'PUT',
        },
        body: processPayloads,
        });

        if (responsePutOperation.body.p_err_code === 'Success') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Operation Changes Saved Successfully!',
            displayMode: 'transient',
            type: 'confirmation',
          });
        } else {
          await Actions.fireNotificationEvent(context, {
            displayMode: 'transient',
            type: 'error',
            summary: 'Error While Saving Operation Changes!',
            message: responsePutOperation.body.p_err_msg,
          });
        }


      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });
    }
  }

  return saveChangesButtonActionChain;
});
