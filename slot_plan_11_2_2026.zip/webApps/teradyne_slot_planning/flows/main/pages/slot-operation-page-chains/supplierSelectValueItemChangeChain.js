define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class supplierSelectValueItemChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.previousValue
     * @param {any} params.value
     * @param {string} params.updatedFrom
     * @param {any} params.key
     * @param {any} params.data
     * @param {any} params.metadata
     * @param {any} params.valueItem
     */
    async run(context, { event, previousValue, value, updatedFrom, key, data, metadata, valueItem }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      const responseVendorID = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetVendorId',
        uriParams: {
          'p_vendorName': value.data.partyname,
        },
      });

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetSupplierSites',
        uriParams: {
          'p_vendor_id': responseVendorID.body.items[0].vendorid,
        },
      });

      if (response.body.items.length === 0) {
        await Actions.fireNotificationEvent(context, {
          type: 'error',
          summary: 'No Supplier Sites exists for this Supplier!',
          displayMode: 'transient',
        });

      } else {
        $variables.supplierSitesADP.data = response.body.items;
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });

    }
  }

  return supplierSelectValueItemChangeChain;
});
