define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterListener extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application, $constants, $variables, $functions } = context;

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      await Actions.callChain(context, {
        chain: 'application:headerLoadData',
        params: {
          'header_id': $application.variables.globalSlotNumber,
        },
      });

      const responseSlotTypelov = await Actions.callRest(context, {
        endpoint: 'SlotPlanningModule/getGetslottypelov',
      });

      const responseSuppliers = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetSuppliers',
      });

      $variables.slotTypeADP.data = responseSlotTypelov.body.items;
      $variables.suppliersADP.data = responseSuppliers.body.items;

      const manufacture = $application.variables.headerVar.manufacture;

      $variables.selectedManufacture = {
        key: $application.variables.headerVar.manufacture,
        data: { partyname: manufacture }        
      };

      const slotType = $application.variables.headerVar.slot_type;

      $variables.selectedSlotType = {
        key: $application.variables.headerVar.slot_type,
        data: { slot_type: slotType }
      };

      if ($application.variables.headerVar.slot_status === "Identified") {
        const responseOperationDetails = await Actions.callRest(context, {
          endpoint: 'ordsService/getOperationTableAction',
          uriParams: {
            'p_slot_number': $application.variables.globalSlotNumber,
          },
        });

        $variables.operationSlotVariables.actualShipDate = responseOperationDetails.body.items[0].actual_date;
      }

      const payload = await $functions.payload('/Custom/Teradyne/Extension/SLOT_PLANNING/Report/TER_GET_ORGANIZATION_NAME_SP_RPT.xdo', 'p_item_number', $application.variables.headerVar.system, undefined, undefined);

      const response = await Actions.callRest(context, {
        endpoint: 'fusionService/runBIPReport',
        body: payload,
      });

      const readBINullData = await $functions.readBINullData(response.body);

      if (readBINullData === 'DQoNCg==') {
        await Actions.fireNotificationEvent(context, {
          type: 'error',
          summary: 'No Organization assigned to this System in Fusion!',
          displayMode: 'transient',
        });
      } else {

        const readBIPreportData = await $functions.readBIPreportData(response.body);

        $variables.planningOrganizationADP.data = readBIPreportData;
      }

      await Actions.callChain(context, {
        chain: 'assignDefaultSingleSelectValue',
      });

      const loadingDialogOpen2 = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      $variables.operationSlotVariables.mrpQtr = $application.variables.headerVar.mrp_qtr;
      $variables.operationSlotVariables.platform = $application.variables.headerVar.platform;
      $variables.operationSlotVariables.system = $application.variables.headerVar.system;
      $variables.operationSlotVariables.slotNumber = $application.variables.headerVar.slot_number;
      $variables.operationSlotVariables.slotStatus = $application.variables.headerVar.slot_status;
      // $variables.operationSlotVariables.slotType = $application.variables.headerVar.slot_type;
      $variables.operationSlotVariables.pdQtr = $application.variables.headerVar.pd_qtr;
      $variables.operationSlotVariables.customer = $application.variables.headerVar.customer;
      // $variables.operationSlotVariables.planningOrganization = $application.variables.headerVar.planning_organization;
      // $variables.operationSlotVariables.manufacture = $application.variables.headerVar.manufacture;
      // $variables.operationSlotVariables.manufactureSite = $application.variables.headerVar.manufacture_site;
      $variables.operationSlotVariables.scheduledDate = $application.variables.headerVar.schedule_date;
      $variables.operationSlotVariables.promisedDate = $application.variables.headerVar.promised_date;
      // $variables.operationSlotVariables.configNumber = $application.variables.headerVar.config_number;
      $variables.operationSlotVariables.operationComments = $application.variables.headerVar.operation_comments;
      
      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });

    }
  }

  return vbEnterListener;
});
