define([
  "knockout",
  "ojs/ojarraydataprovider"
], (
  ko,
  ArrayDataProvider
) => {
  'use strict';

  class PageModule {

    payload(arg1, arg2, arg3, arg4, arg5) {

      const xmlbody = `<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:pub="http://xmlns.oracle.com/oxp/service/PublicReportService">
          <soap:Header />
          <soap:Body>
            <pub:runReport>
                <pub:reportRequest>
                  <pub:parameterNameValues>
                      <pub:item>
                        <pub:name>${arg2}</pub:name>
                        <pub:values>
                            <pub:item>${arg3}</pub:item>
                        </pub:values>
                      </pub:item>
                      <pub:item>
                        <pub:name>${arg4}</pub:name>
                        <pub:values>
                            <pub:item>${arg5}</pub:item>
                        </pub:values>
                      </pub:item>
                  </pub:parameterNameValues>
                  <pub:reportAbsolutePath>${arg1}</pub:reportAbsolutePath>
                  <pub:sizeOfDataChunkDownload>-1</pub:sizeOfDataChunkDownload>
                </pub:reportRequest>
            </pub:runReport>
          </soap:Body>
          </soap:Envelope>`;

      return xmlbody;
    }

    readBIPreportData(req) {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(req, "text/xml");
      const base64ReportByte = xmlDoc.querySelector("reportBytes").textContent;
      const base64DecodedReportData = atob(base64ReportByte);
      const utf8Bytes = new Uint8Array(base64DecodedReportData.length);
      for (let i = 0; i < base64DecodedReportData.length; i++) {
        utf8Bytes[i] = base64DecodedReportData.charCodeAt(i);
      }
      const decoder = new TextDecoder('utf-8');
      const decodedText = decoder.decode(utf8Bytes);
      let jsonArray = JSON.parse(decodedText);
      return jsonArray;

    }

    readBINullData(req) {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(req, "text/xml");
      const base64ReportByte = xmlDoc.querySelector("reportBytes").textContent;
      return base64ReportByte;
    }

    dateToQuarter(dateStr) {
      if (typeof dateStr !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        throw new Error('Invalid date format. Expected "yyyy-MM-dd".');
      }

      const [yStr, mStr] = dateStr.split("-");
      const year = Number(yStr);
      const month = Number(mStr); // 1-12

      if (!Number.isInteger(year) || !Number.isInteger(month) || month < 1 || month > 12) {
        throw new Error("Invalid year or month value.");
      }

      const quarter = Math.floor((month - 1) / 3) + 1;
      return `${year}Q${quarter}`;
    }

    fridayOfSameWeek(dateStr) {
      if (typeof dateStr !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        throw new Error('Invalid date format. Expected "yyyy-MM-dd".');
      }

      const [yStr, mStr, dStr] = dateStr.split("-");
      const y = Number(yStr);
      const m = Number(mStr);
      const d = Number(dStr);

      const dt = new Date(Date.UTC(y, m - 1, d));
      if (
        dt.getUTCFullYear() !== y ||
        dt.getUTCMonth() !== m - 1 ||
        dt.getUTCDate() !== d
      ) {
        throw new Error("Invalid date value.");
      }

      const jsDay = dt.getUTCDay();
      const isoDay = jsDay === 0 ? 7 : jsDay;

      const targetIsoDay = 5;
      const offsetDays = targetIsoDay - isoDay;

      dt.setUTCDate(dt.getUTCDate() + offsetDays);

      const yyyy = dt.getUTCFullYear();
      const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
      const dd = String(dt.getUTCDate()).padStart(2, "0");
      return `${yyyy}-${mm}-${dd}`;
    }

    filterArrayDataProviderByDeletedCSV(adp, csvValues, keyField) {
      const filterSet = new Set(csvValues.split(',').map(v => v.trim()));

      const filteredData = adp.filter(item =>
        !filterSet.has(String(item[keyField]))
      );

      return new ArrayDataProvider(filteredData, { keyAttributes: keyField });
    }

    processPayloads(payloadData, slotTypeValue, plannedOrg, configNumber, mfr, mfrSite) {
      const slot = payloadData;
      // const finalPayload = {};
      // let processedObj = {};

      let processedObj = {
        configNumber: slot?.configNumber?.[0] ?? configNumber,
        customer: slot.customer,
        manufacture: slot?.manufacture?.[0] ?? mfr,
        manufactureSite: slot?.manufactureSite?.[0] ?? mfrSite,
        mrpQtr: slot.mrpQtr,
        operationComments: slot.operationComments,
        pdQtr: slot.pdQtr,
        planningOrganization: slot?.planningOrganization?.[0] ?? plannedOrg,
        platform: slot.platform,
        promisedDate: slot.promisedDate,
        scheduledDate: slot.scheduledDate,
        slotNumber: slot.slotNumber,
        slotStatus: slot.slotStatus,
        slotType: slot?.slotType?.[0] ?? slotTypeValue,
        system: slot.system,
        createdBy: slot.createdBy,
        updatedDate: slot.updatedDate,
        updatedBy: slot.updatedBy
      };

      return processedObj;
    }

  }

  return PageModule;
});
