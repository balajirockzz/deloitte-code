define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class viewConfigButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $fragment, $application, $constants, $variables } = context;

      const viewConfigDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#viewConfigDialog',
        method: 'open',
      });

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetAllConfigDetails',
      });

      const loadingDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'open',
      });

      if (response.body.items.length === 0) {
        await Actions.fireNotificationEvent(context, {
          type: 'error',
          summary: 'No Config exists!',
          displayMode: 'transient',
        });

      } else {

        $variables.getAllConfigDetailsADP.data = response.body.items;
      }

      const loadingDialogClose = await Actions.callComponentMethod(context, {
        selector: '#loadingDialog',
        method: 'close',
      });

    }
  }

  return viewConfigButtonActionChain;
});
