define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class onClickViewButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {string} params.slotNumber
     */
    async run(context, { event, originalEvent, slotNumber }) {
      const { $fragment, $application, $constants, $variables } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'ordsService/getGetViewDetails',
        uriParams: {
          'p_slot_number': $variables.slotNumberVar,
        },
      });

      $variables.viewObj.Actual_Ship_Date = response.body.items[0].actual_date;
      $variables.viewObj.Change_Request_Number = response.body.items[0].request_number;
      $variables.viewObj.Config_Number = response.body.items[0].config_number;
      $variables.viewObj.Customer = response.body.items[0].customer;
      $variables.viewObj.Customer_Request_Delivery_Date = response.body.items[0].customer_date;
      $variables.viewObj.Customer_Site_id = response.body.items[0].customer_site_id;
      $variables.viewObj.Demand_Class = response.body.items[0].demand_class;
      $variables.viewObj.Finance_Comments = response.body.items[0].finance_comments;
      $variables.viewObj.Forecast_Name = response.body.items[0].forecast_name;
      $variables.viewObj.Marketing_Comments = response.body.items[0].marketing_comments;
      $variables.viewObj.Mfr = response.body.items[0].mfr;
      $variables.viewObj.Mfr_Site = response.body.items[0].mfr_site;
      $variables.viewObj.MRP_Qtr = response.body.items[0].mrp_qtr;
      $variables.viewObj.Operation_Comments = response.body.items[0].operations_comments;
      $variables.viewObj.PD_Qtr = response.body.items[0].pd_qtr;
      $variables.viewObj.Planning_Organization = response.body.items[0].planning_organization;
      $variables.viewObj.Platform = response.body.items[0].platform;
      $variables.viewObj.Promise_Date = response.body.items[0].promised_date;
      $variables.viewObj.Revenue = response.body.items[0].revenue;
      $variables.viewObj.Sales_Order = response.body.items[0].sales_order;
      $variables.viewObj.Schedule_Date = response.body.items[0].schedule_date;
      $variables.viewObj.Slot_Number = response.body.items[0].slot_number;
      $variables.viewObj.Slot_Status = response.body.items[0].slot_status;
      $variables.viewObj.Slot_Type = response.body.items[0].slot_type;
      $variables.viewObj.System = response.body.items[0].system;

      const viewDetailsDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#viewDetailsDialog',
        method: 'open',
      });
    }
  }

  return onClickViewButtonActionChain;
});
